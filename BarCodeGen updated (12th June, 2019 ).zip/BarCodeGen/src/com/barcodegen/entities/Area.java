package com.barcodegen.entities;

public class Area {

	private int area_code;
	private String area_name;
	public Area(int area_code, String area_name) {
		super();
		this.area_code = area_code;
		this.area_name = area_name;
	}
	public Area() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getArea_code() {
		return area_code;
	}
	public void setArea_code(int area_code) {
		this.area_code = area_code;
	}
	public String getArea_name() {
		return area_name;
	}
	public void setArea_name(String area_name) {
		this.area_name = area_name;
	}
	@Override
	public String toString() {
		return "Area [area_code=" + area_code + ", area_name=" + area_name + "]";
	}
	
	
}
