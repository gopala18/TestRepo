package com.barcodegen.entities;

import java.time.LocalDateTime;

public class BarCodeGen {

	private String barCode;
	private LocalDateTime date_time;
	private Category category;
	private Area area;
	private double weight;
	public BarCodeGen() {
		super();
		// TODO Auto-generated constructor stub
	}
	public BarCodeGen(String barCode, LocalDateTime date_time, Category category, Area area, double weight) {
		super();
		this.barCode = barCode;
		this.date_time = date_time;
		this.category = category;
		this.area = area;
		this.weight = weight;
	}
	public String getBarCode() {
		return barCode;
	}
	public void setBarCode(String barCode) {
		this.barCode = barCode;
	}
	public LocalDateTime getDate_time() {
		return date_time;
	}
	public void setDate_time(LocalDateTime date_time) {
		this.date_time = date_time;
	}
	public Category getCategory() {
		return category;
	}
	public void setCategory(Category category) {
		this.category = category;
	}
	public Area getArea() {
		return area;
	}
	public void setArea(Area area) {
		this.area = area;
	}
	public double getWeight() {
		return weight;
	}
	public void setWeight(double weight) {
		this.weight = weight;
	}
	@Override
	public String toString() {
		return "BarCodeGen [barCode=" + barCode + ", date_time=" + date_time + ", category=" + category + ", area="
				+ area + ", weight=" + weight + "]";
	}
	
	
}
