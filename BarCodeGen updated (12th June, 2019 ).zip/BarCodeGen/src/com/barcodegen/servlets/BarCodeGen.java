package com.barcodegen.servlets;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.barcodegen.services.BarCodeService;

/**
 * Servlet implementation class BarCodeGen
 */


@WebServlet("/barcodeimage")
public class BarCodeGen extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BarCodeGen() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("image/jpg");
		
		System.out.println("Inside doGet barcodeimage");
		BarCodeService barcodeService = new BarCodeService();
		ByteArrayOutputStream barcodeImage = barcodeService.getBarCodeImage(barcodeService.generateBarCode());

		ServletOutputStream responseOutputStream = response.getOutputStream();

		responseOutputStream.write(barcodeImage.toByteArray());
		responseOutputStream.flush();
		responseOutputStream.close();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
