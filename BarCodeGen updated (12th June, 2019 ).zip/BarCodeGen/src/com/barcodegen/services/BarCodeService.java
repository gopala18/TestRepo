package com.barcodegen.services;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Random;

import org.krysalis.barcode4j.impl.code39.Code39Bean;
import org.krysalis.barcode4j.output.bitmap.BitmapCanvasProvider;
import org.krysalis.barcode4j.tools.UnitConv;

import com.barcodegen.dao.BarCodeServiceProvider;
import com.barcodegen.entities.BarCodeGen;
import com.barcodegen.utils.DBConnector;

public class BarCodeService implements BarCodeServiceProvider {

	@Override
	public String generateBarCode() {
		Random r = new Random( System.currentTimeMillis() );
	    int randomNumber=((1 + r.nextInt(2)) * 10000 + r.nextInt(10000));
	    StringBuilder barCode=new StringBuilder("IN5119");
	    barCode.append(randomNumber);
	        
		return barCode.toString();
	}

	@Override
	public ArrayList<BarCodeGen> searchBarCode(LocalDateTime from, LocalDateTime to) throws FileNotFoundException, IOException, SQLException, ClassNotFoundException {
		ArrayList<BarCodeGen> barCodes=new ArrayList<>();
		Connection conn=DBConnector.getConnection();
		AreaService areaService=new AreaService();
		CategoryService categoryService=new CategoryService();
		PreparedStatement ps=conn.prepareStatement("SELECT barcode,date_time,category_id,area_code FROM barcode WHERE date_time BETWEEN ? AND ?");
		ps.setTimestamp(1, java.sql.Timestamp.valueOf(from));
		ps.setTimestamp(2, java.sql.Timestamp.valueOf(to));
		ResultSet rs=ps.executeQuery();
		while(rs.next()) {
			
			barCodes.add(new BarCodeGen(rs.getString("barcode"),rs.getTimestamp("date_time").toLocalDateTime(),categoryService.getCategory(rs.getInt("category_id")),areaService.getArea(rs.getInt("area_code")),0.0));
		}
		return barCodes;
	}

	@Override
	public ByteArrayOutputStream getBarCodeImage(String barCode) throws IOException {
		 Code39Bean bean = new Code39Bean();
		 
	        final int dpi = 150;
	 
	        //Configure the barcode generator
	        bean.setModuleWidth(UnitConv.in2mm(1.0f / dpi)); //makes the narrow bar, width exactly one pixel
	        bean.setWideFactor(3);
	        bean.doQuietZone(false);
	        ByteArrayOutputStream out = new ByteArrayOutputStream();
	        BitmapCanvasProvider canvas = new BitmapCanvasProvider(
	                out, "image/x-png", dpi, BufferedImage.TYPE_BYTE_BINARY, false, 0);
	 
	            //Generate the barcode
	            bean.generateBarcode(canvas, barCode);
	 
	            //Signal end of generation
	            canvas.finish();
		return out;
	}

	@Override
	public boolean saveBarcode(BarCodeGen barcode) {
        boolean insertFlag=false;
        Connection conn;
		try {
			conn = DBConnector.getConnection();
			PreparedStatement ps=conn.prepareStatement("INSERT INTO barcode values(?,?,?,?)");
	        ps.setString(1, barcode.getBarCode());
	        ps.setTimestamp(2, java.sql.Timestamp.valueOf(barcode.getDate_time()));
	        ps.setObject(3, barcode.getArea());
	        ps.setObject(4, barcode.getCategory());
		} catch (ClassNotFoundException | IOException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
        return insertFlag;
	}

}
