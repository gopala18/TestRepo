package com.barcodegen.services;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.barcodegen.dao.CategoryServiceProvider;
import com.barcodegen.entities.Area;
import com.barcodegen.entities.Category;
import com.barcodegen.utils.DBConnector;

public class CategoryService implements CategoryServiceProvider {

	@Override
	public Category getCategory(int categoryID) throws FileNotFoundException, IOException, SQLException, ClassNotFoundException {
		Connection conn=DBConnector.getConnection();
		PreparedStatement ps=conn.prepareStatement("SELECT category_id,category_desc FROM category WHERE category_id=?");
		ps.setInt(1, categoryID);
		ResultSet rs=ps.executeQuery();
		rs.next();
		Category foundCategory=new Category(rs.getInt("category_id"),rs.getString("category_desc"));
		conn.close();
		return foundCategory;
	}

	@Override
	public List<Category> getAllCategories() throws FileNotFoundException, IOException, SQLException,ClassNotFoundException {
		ArrayList<Category> categoryList=new ArrayList<Category>();
		Connection conn=DBConnector.getConnection();
		PreparedStatement ps=conn.prepareStatement("SELECT category_id,category_desc FROM category");
		
		ResultSet rs=ps.executeQuery();
		
		while(rs.next()) {
			categoryList.add(new Category(rs.getInt("category_id"),rs.getString("category_desc")));
		}
		conn.close();
		return categoryList;
	}
	

}
