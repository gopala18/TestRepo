package com.barcodegen.dao;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import com.barcodegen.entities.Area;

public interface AreaServiceProvider {
	public Area getArea(int areaCode) throws FileNotFoundException, IOException, SQLException, ClassNotFoundException;
	public List<Area> getAllAreas() throws FileNotFoundException, IOException, SQLException,ClassNotFoundException;

}
