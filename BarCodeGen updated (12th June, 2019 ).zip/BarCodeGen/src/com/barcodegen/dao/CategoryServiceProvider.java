package com.barcodegen.dao;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import com.barcodegen.entities.Category;

public interface CategoryServiceProvider {
	public Category getCategory(int categoryID) throws FileNotFoundException, IOException, SQLException, ClassNotFoundException;
	public List<Category> getAllCategories()throws FileNotFoundException, IOException, SQLException,ClassNotFoundException;

}
