package com.barcodegen.dao;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.ArrayList;

import com.barcodegen.entities.BarCodeGen;

public interface BarCodeServiceProvider {

	public String generateBarCode();

	public ByteArrayOutputStream getBarCodeImage(String barCode) throws IOException;
	public boolean saveBarcode(BarCodeGen barcode);

	public ArrayList<BarCodeGen> searchBarCode(LocalDateTime from, LocalDateTime to)
			throws FileNotFoundException, IOException, SQLException, ClassNotFoundException;
}
