package com.htc.selenium.day17;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import com.htc.selenium.drivers.WebDriversFactory;

public class MouseHover {

	public static WebDriver driver;

	public static void main(String[] args) {

		driver = WebDriversFactory.getWebdriver("chrome");

		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		driver.get("http://store.demoqa.com/");

		WebElement element = driver.findElement(By.linkText("Product Category"));

		Actions action = new Actions(driver);

		action.moveToElement(element).build().perform();

		driver.findElement(By.linkText("iPads")).click();

	}

}