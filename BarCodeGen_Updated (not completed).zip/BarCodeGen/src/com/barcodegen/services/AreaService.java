package com.barcodegen.services;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.barcodegen.dao.AreaServiceProvider;
import com.barcodegen.entities.Area;
import com.barcodegen.utils.DBConnector;

public class AreaService implements AreaServiceProvider{

	@Override
	public Area getArea(int areaCode) throws FileNotFoundException, IOException, SQLException, ClassNotFoundException {
		Connection conn=DBConnector.getConnection();
		PreparedStatement ps=conn.prepareStatement("SELECT area_code,area_name FROM area WHERE area_code=?");
		ps.setInt(1, areaCode);
		ResultSet rs=ps.executeQuery();
		rs.next();
		Area foundArea=new Area(rs.getInt("area_code"),rs.getString("area_name"));
		conn.close();
		return foundArea;
	}

	@Override
	public List<Area> getAllAreas() throws FileNotFoundException, IOException, SQLException {
		ArrayList<Area> areaList=new ArrayList<Area>();
		Connection conn=DBConnector.getConnection();
		PreparedStatement ps=conn.prepareStatement("SELECT area_code,area_name FROM area");
		
		ResultSet rs=ps.executeQuery();
		
		while(rs.next()) {
			areaList.add(new Area(rs.getInt("area_code"),rs.getString("area_name")));
		}
		conn.close();
		return areaList;
	}
	

}
