package com.barcodegen.services;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;

import com.barcodegen.dao.UserServiceProvider;
import com.barcodegen.utils.DBConnector;

public class UserService implements UserServiceProvider{

	@Override
	public boolean validateUser(String userName, String password) throws FileNotFoundException, IOException, SQLException, InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException, ClassNotFoundException {
		Connection conn=DBConnector.getConnection();
		boolean validUserFlag=false;
		PreparedStatement ps=conn.prepareStatement("SELECT COUNT(*) AS count FROM users WHERE userName=? AND password=?");
		ps.setString(1, userName);
		ps.setString(2, this.encryptPassword(password));
		System.out.println("encypt:"+this.encryptPassword(password));
		ResultSet rs=ps.executeQuery();
		rs.next();
		System.out.println("Count:"+rs.getInt("count"));
		if(rs.getInt("count")==1)
			validUserFlag=true;
		conn.close();
		return validUserFlag;
	}

	@Override
	public String encryptPassword(String password) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException{
		// create a binary key from the argument key (seed)
		String key="password";
	      SecureRandom sr = new SecureRandom(key.getBytes());
	      KeyGenerator kg = KeyGenerator.getInstance("RC4");
	      kg.init(sr);
	      SecretKey sk = kg.generateKey();
	  
	      // create an instance of cipher
	      Cipher cipher = Cipher.getInstance("RC4");
	  
	      // initialize the cipher with the key
	      cipher.init(Cipher.ENCRYPT_MODE, sk);
	  
	      // enctypt!
	      byte[] encrypted = cipher.doFinal(password.getBytes());
	  
	      return encrypted.toString();
		
	}

	@Override
	public String decryptPassword(String encryptedPassword)throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
		String key="password";
		SecureRandom sr = new SecureRandom(key.getBytes());
	      KeyGenerator kg = KeyGenerator.getInstance("RC4");
	      kg.init(sr);
	      SecretKey sk = kg.generateKey();
	  
	      // do the decryption with that key
	      Cipher cipher = Cipher.getInstance("RC4");
	      cipher.init(Cipher.DECRYPT_MODE, sk);
	      byte[] decrypted = cipher.doFinal(encryptedPassword.getBytes());
	  
		return decrypted.toString();
	}

	@Override
	public boolean updatePassword(String email, String newPassword) throws FileNotFoundException, IOException, SQLException, InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException, ClassNotFoundException {
		boolean updatePasswordFlag=false;
		Connection conn=DBConnector.getConnection();
		PreparedStatement ps=conn.prepareStatement("UPDATE users SET password=? WHERE email=?");
		ps.setString(1, this.encryptPassword(newPassword));
		ps.setString(2, email);
		if(ps.executeUpdate()==1)
			updatePasswordFlag=true;
		conn.close();
		return updatePasswordFlag;
	}

}
