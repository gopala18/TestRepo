package com.barcodegen.entities;

import com.barcodegen.services.CategoryService;

public class HelloExample1 {
 
    public static void main(String[] args) throws Exception{
    	
    	CategoryService categoryService=new CategoryService();
		for(Category category:categoryService.getAllCategories()){
			System.out.println(category.getCategory_ID()+"=="+category.getCategory_desc());
		}
    	
    	/*UserService user=new UserService();
    	System.out.println(user.encryptPassword("123Welcome"));
    	System.out.println(user.validateUser("gopi", "123Welcome"));*/
    	
    	
    	
    	/*Connection conn=DBConnector.getConnection();
		PreparedStatement ps=conn.prepareStatement("SELECT area_code,area_name FROM area WHERE area_code=?");
		ps.setInt(1, 101);
		ResultSet rs=ps.executeQuery();
		rs.next();
		System.out.println(new Area(rs.getInt("area_code"),rs.getString("area_name")));*/
    	/*
    	//Create the barcode bean
        Code39Bean bean = new Code39Bean();
 
        final int dpi = 150;
 
        //Configure the barcode generator
        bean.setModuleWidth(UnitConv.in2mm(1.0f / dpi)); //makes the narrow bar, width exactly one pixel
        bean.setWideFactor(3);
        bean.doQuietZone(false);
 
        //Open output file
        File outputFile = new File("HelloWorld_Barcode.png");
        if(!outputFile.exists())
        	outputFile.createNewFile();
        OutputStream out = new FileOutputStream(outputFile);
 
        try {
 
            //Set up the canvas provider for monochrome PNG output
            BitmapCanvasProvider canvas = new BitmapCanvasProvider(
                out, "image/x-png", dpi, BufferedImage.TYPE_BYTE_BINARY, false, 0);
 
            //Generate the barcode
            bean.generateBarcode(canvas, "Hello World");
 
            //Signal end of generation
            canvas.finish();
        } finally {
            out.close();
        }
        */
    }
}
