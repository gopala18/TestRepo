package com.barcodegen.entities;

public class Category {

	private int category_ID;
	private String category_desc;
	public Category() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Category(int category_ID, String category_desc) {
		super();
		this.category_ID = category_ID;
		this.category_desc = category_desc;
	}
	public int getCategory_ID() {
		return category_ID;
	}
	public void setCategory_ID(int category_ID) {
		this.category_ID = category_ID;
	}
	public String getCategory_desc() {
		return category_desc;
	}
	public void setCategory_desc(String category_desc) {
		this.category_desc = category_desc;
	}
	@Override
	public String toString() {
		return "Category [category_ID=" + category_ID + ", category_desc=" + category_desc + "]";
	}
	
}
