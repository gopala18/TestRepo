


        $("barcodegen").load (
            function() {
                $.ajax({
                    type: "POST",
                    url: "populateDropdown",
                    data: {category: $category.attr("selectedIndex") },
                    success: function(data){
                        $("#category").append(data)
                    }
                });
            }
        );
