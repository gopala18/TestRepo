package com.htc.jquerydemo.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.htc.jquerydemo.dto.Students;

public class StudentsDAOImpl {

	public boolean setStudent(Students student){
		boolean insertStatus=false;
		
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("studDB");
		EntityManager manager=factory.createEntityManager();
		EntityTransaction trans=manager.getTransaction();
		trans.begin();
		try{
			manager.persist(student);
			insertStatus=true;
			trans.commit();
		}
		catch(Exception e){
			e.printStackTrace();
			trans.rollback();
		}
		return insertStatus;
	}
	
	public Students getStudent(int regNo){
		
		Students std=new Students();
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("studDB");
		EntityManager manager=factory.createEntityManager();
		EntityTransaction trans=manager.getTransaction();
		trans.begin();
		try{
			std=manager.find(Students.class, regNo);
			trans.commit();
		}catch(Exception e){
			e.printStackTrace();
			trans.rollback();
		}
		return std;
	}
}
