package com.htc.jquerydemo.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="students")
public class Students implements Serializable{
	
	@Id
	private int regNo;
	@Column
	private String name;
	@Column
	private String department;
	
	
	public Students(int regNo, String name, String department) {
		super();
		this.regNo = regNo;
		this.name = name;
		this.department = department;
	}
	public Students() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public int getRegNo() {
		return regNo;
	}
	public void setRegNo(int regNo) {
		this.regNo = regNo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	@Override
	public String toString() {
		return "Students [regNo=" + regNo + ", name=" + name + ", department=" + department + "]";
	}
	
	

}
