package com.htc.jquerydemo.main;

import com.htc.jquerydemo.dao.StudentsDAOImpl;
import com.htc.jquerydemo.dto.Students;

public class Main {
	public static void main(String[] args) {
		StudentsDAOImpl stdImpl=new StudentsDAOImpl();
		boolean insertStatus=stdImpl.setStudent(new Students(123,"Gopi","MCA"));
		System.out.println("insert status:"+insertStatus);
	}

}
