package com.htc.jquery.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.htc.jquerydemo.dao.StudentsDAOImpl;
import com.htc.jquerydemo.dto.Students;

@WebServlet("/StdServ")
public class StdServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		StudentsDAOImpl std = new StudentsDAOImpl();
		Students student = new Students();
		student = std.getStudent(Integer.parseInt(request.getParameter("regNo")));
		PrintWriter pw = response.getWriter();
		if (student != null) {
			pw.println("exist");
			
		} else
			pw.println("notExist");

			}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		/*StudentsDAOImpl std = new StudentsDAOImpl();
		Students student = new Students();
		student = std.getStudent(Integer.parseInt(request.getParameter("regNo")));
		PrintWriter pw = response.getWriter();
		if (student != null) {
			pw.println("exist");
		} else
			pw.println("notExist");
*/
	}

}
