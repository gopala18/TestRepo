//login form validate

$(document).ready(function() {

	$('#submit').click(function(event) {
		var userName = $('#userName').val();
		var password = $('#password').val();

		if (userName == "") {
			window.alert("username null");
			$('#nameError').show();
			$('#nameError').html = "Please enter userName";
			$('#nameError').addClass('errorClass');
			event.preventDefault();
		} else {
			$('#nameError').hide();
		}

		if (password == "") {
			window.alert("password null");
			$('#passError').show();
			$('#passError').html = "Please enter the password";
			$('#passError').addClass('errorClass');
			event.preventDefault();
		} else {
			$('#passError').hide();
		}
	});
}

);