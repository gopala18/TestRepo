$(document).ready(function() {
	$('#submit').click(function(event) {
		alert("click submit");
		var regNo = $('#regNo').val();
		var name = $('#name').val();
		var dept = $('#department').val();
		if (regNo == "" || name == "" || dept == "") {
			alert("if statement");
			$('#cerror').show();
			$('#cerror').html("All fields are Mandatory");
			$('#cerror').css("color", "red");
			event.preventDefault();
		} else {
			alert("else part");
			$('#cerror').hide();
			$('#cerror').html("");
			
		}
	});
	$('#regNo').blur(function(event) {
		alert("blur event");
		var regNo = $('#regNo').val();

		if (regNo == "") {

			$('#error').show();
			$('#error').html("Please enter Regno");
			$('#error').css("color", "red");
			event.preventDefault();
		} else {
			alert("ajax call");
			$.ajax({
				type : "GET",
				url : "StdServ",
				data : "regNo=" + regNo,
				success : function(output) {
					window.alert("test ajax");
					if (output.trim() == "exist") {
						$('#error').show();
						$('#error').html("RegNo already exist");
						$('#error').css("color", "red");
						event.preventDefault();
					} else {
						$('#error').hide();
						$('#error').html(" ");
					}
				},
				error : function(req, err, status) {
					console.log(err);
				}

			});

		}

	});
}

);