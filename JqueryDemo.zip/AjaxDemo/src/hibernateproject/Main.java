package hibernateproject;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import java.util.Iterator;



public class Main {

	public static void main(String[] args) {
		
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("studDB");
		EntityManager manager=factory.createEntityManager();
		EntityTransaction trans=manager.getTransaction();
		trans.begin();
		try{
			manager.persist(new Students(124,"Darwin","MCA",new Address(121,"karambakkam","porur",600116)));
			//Query qry=manager.createQuery("select s from Students s where regNo=:reg");
			/*Query qry=manager.createNamedQuery("selectByRegNo");
			qry.setParameter("reg", 123);
			List<Students> rs=qry.getResultList();
			Iterator<Students> itr=rs.iterator();
			//itr.next();
			while(itr.hasNext()){
				System.out.println(itr.next());
			}*/
			
			trans.commit();
		}
		catch(Exception e){
			trans.rollback();
		}
		
		System.out.println("Object persisted in DB...");

	}

}
