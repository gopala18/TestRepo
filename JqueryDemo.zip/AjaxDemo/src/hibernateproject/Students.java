package hibernateproject;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;

@Entity
@NamedQuery(name="selectByRegNo", query="select s from Students s where s.regNo=:reg")
public class Students {
	
	@Id
	@Column
	private int regNo;
	@Column
	private String name;
	@Column
	private String department;
	@OneToOne(fetch=FetchType.EAGER)
	@JoinColumn(table="Address", referencedColumnName="doorNo")
	private Address address;
	
	
	
	
	public int getRegNo() {
		return regNo;
	}
	public void setRegNo(int regNo) {
		this.regNo = regNo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	@Override
	public String toString() {
		return "Students [regNo=" + regNo + ", name=" + name + ", department=" + department + ", address=" + address
				+ "]";
	}
	public Students(int regNo, String name, String department) {
		super();
		this.regNo = regNo;
		this.name = name;
		this.department = department;
	}
	
	
	
	public Students(int regNo, String name, String department, Address address) {
		super();
		this.regNo = regNo;
		this.name = name;
		this.department = department;
		this.address = address;
	}
	public Students() {
		super();
		// TODO Auto-generated constructor stub
	}
	

}
