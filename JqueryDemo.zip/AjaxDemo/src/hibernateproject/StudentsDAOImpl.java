package hibernateproject;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

public class StudentsDAOImpl {
	static Session session;
	
	public Session getSession(){
		Configuration config=new Configuration();
		config.configure();
		StandardServiceRegistryBuilder build=new StandardServiceRegistryBuilder();
		build=build.applySettings(config.getProperties());
		ServiceRegistry registry=build.build();
		SessionFactory sf=config.buildSessionFactory(registry);

		session=sf.openSession();
		
		
		return session;
	}
	public void saveStudent(Students student){
		getSession().save(student);
	}
	
	public Students getStudent(int regNo){
		Students std=new Students();
		
		std=(Students) getSession().load(Students.class, regNo);
		return std;
	}
	

}
