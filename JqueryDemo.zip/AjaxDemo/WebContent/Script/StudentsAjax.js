var req;
function getRequestObject(){
	if(window.ActiveXObject){
		return new ActiveXObject("Microsoft.XMLHTTP");
	}else if(window.XMLHttpRequest){
		return new XMLHttRequest();
	}else
		return null;
	
}

function sendGetRequest(){
	req = getRequestObject();
	var regno = document.getElementById("regNo").value;
	var url = "checkResponse?regNo=" + regno ;
	req.open("GET", url , true);
	req.onreadystatechange=processXmlResponse;
	req.send();
}

function sendPostRequest(){
	req = getRequestObject();
	var regno = document.getElementById("regNo").value;
	var url = "checkResponse";
	
	req.open("POST", url , true);
	req.onreadystatechange=processXmlResponse;
	req.setRequestHeader("content-type","application/x-www-form-urlencoded");
	req.send("regNo=" + regno);
}

function processTextResponse() {
		if(req.readyState == 4) {
			if(req.status == 200) {
					if(req.responseText.trim() == "TRUE")
						document.getElementById("errorMsg").innerHTML = "Already Updated";
					else
						document.getElementById("errorMsg").innerHTML = "";
			}
			else{
				window.alert("Response status:" + req.status);
			}
		}
}

function processXmlResponse() {
		if(req.readyState == 4) {
			if(req.status == 200) {
					var response = req.responseXML;
					var output =response.getElementsByTagName("EXISTS")[0].childNodes[0].nodeValue;
					if(output == "TRUE") {
						document.getElementById("errorMsg").innerHTML = "Already Updated";
					}
					else{
						document.getElementById("errorMsg").innerHTML = "";
					}
			}
			else{
				window.alert("Response status:" + req.status);
			}
		}
}
