package com.htc.springdemo.main;

import com.htc.springdemo.Circle;
import com.htc.springdemo.Drawing;
import com.htc.springdemo.Shape;

public class ShapeMain {

	public static void main(String[] args) {
		//Shape shape=new Triangle();
		Shape shape=new Circle();
		shape.draw();
		
		Drawing drawing=new Drawing();
		drawing.setShape(shape);
		drawing.drawShape();
	}
}
