package com.htc.springdemo;

public class Circle implements Shape{

	public void draw() {
		System.out.println("Draw Circle");
	}
}
