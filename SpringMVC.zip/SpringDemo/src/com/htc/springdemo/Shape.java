package com.htc.springdemo;

public interface Shape {

	public void draw();
}
