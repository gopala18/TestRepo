package com.htc.springmvc.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class EmployeeController{
	@RequestMapping("/home")
	public ModelAndView homePage() {
		return new ModelAndView("home","message","This is a Spring MVC View");
	}

}
