package com.htc.jpa.main;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.htc.jpa.dao.Employee;

public class Main {
public static void main(String[] args) {
	EntityManagerFactory entityFactory=Persistence.createEntityManagerFactory("JPA_Demo");
	EntityManager entityManager=entityFactory.createEntityManager();
	entityManager.getTransaction().begin();
	
	entityManager.persist(new Employee(123,"Gopi"));
	
	entityManager.getTransaction().commit();
	
	
	
}
}
