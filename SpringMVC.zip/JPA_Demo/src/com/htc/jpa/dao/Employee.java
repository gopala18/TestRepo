package com.htc.jpa.dao;

import java.io.Serializable;
import java.lang.String;
import javax.persistence.*;

@Entity
@Table(name="Employee")
public class Employee implements Serializable {

	   
	@Id
	private int empID;   
	@Column
	private String empName;
	private static final long serialVersionUID = 1L;

	public Employee(int empID, String empName) {
		super();
		this.empID = empID;
		this.empName = empName;
	}
	@Override
	public String toString() {
		return "Employee [empID=" + empID + ", empName=" + empName + "]";
	}
	public Employee() {
		super();
	}   
	public int getEmpID() {
		return this.empID;
	}

	public void setEmpID(int empID) {
		this.empID = empID;
	}   
	public String getEmpName() {
		return this.empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}
   
}
