package com.htc.xmlparsers.dom;

import java.io.File;
import java.io.IOException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class DOMParser {

	public static void main(String argv[]) {

	   try {
		String filepath = "emp.xml";
		DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
		Document doc = docBuilder.parse(filepath);

		// Get the root element
		Node employees = doc.getFirstChild();

		// Get the staff element , it may not working if tag has spaces, or
		// whatever weird characters in front...it's better to use
		// getElementsByTagName() to get it directly.
		// Node emp = employees.getFirstChild();

		// Get the staff element by tag name directly
		Node emp = doc.getElementsByTagName("emp").item(0);

		// update emp attribute
		NamedNodeMap attr = emp.getAttributes();
		Node nodeAttr = attr.getNamedItem("empid");
		nodeAttr.setTextContent("e121");

		// append a new node to emp
		Element newEmp = doc.createElement("emp");
		newEmp.setAttribute("empId", "123");
		
		Element empName=doc.createElement("empName");
		empName.appendChild(doc.createTextNode("Gopi"));
		newEmp.appendChild(empName);
		
		Element job=doc.createElement("job");
		job.appendChild(doc.createTextNode("Trainer"));
		newEmp.appendChild(job);
		
		Element salary=doc.createElement("salary");
		salary.appendChild(doc.createTextNode("20000.00"));
		newEmp.appendChild(salary);
		
		
		Element contactNo=doc.createElement("ContactNo");
		
		Element mobile=doc.createElement("mobile");
		mobile.appendChild(doc.createTextNode("7845781446"));
		contactNo.appendChild(mobile);
		
		Element landline=doc.createElement("landline");
		landline.appendChild(doc.createTextNode("24762718"));
		contactNo.appendChild(landline);
		
		newEmp.appendChild(contactNo);
		employees.appendChild(newEmp);
		
		/*age.appendChild(doc.createTextNode("28"));
		emp.appendChild(age);*/

		// loop the staff child node
		/*NodeList list = emp.getChildNodes();

		for (int i = 0; i < list.getLength(); i++) {
			
                   Node node = list.item(i);

		   // get the salary element, and update the value
		   if ("mobile".equals(node.getNodeName())) {
			node.setTextContent("7845781446");
		   }

                   //remove firstname
		   if ("landline".equals(node.getNodeName())) {
			emp.removeChild(node);
		   }

		}*/

		// write the content into xml file
		TransformerFactory transformerFactory = TransformerFactory.newInstance();
		Transformer transformer = transformerFactory.newTransformer();
		DOMSource source = new DOMSource(doc);
		StreamResult result = new StreamResult(new File(filepath));
		transformer.transform(source, result);

		System.out.println("Done");

	   } catch (ParserConfigurationException pce) {
		pce.printStackTrace();
	   } catch (TransformerException tfe) {
		tfe.printStackTrace();
	   } catch (IOException ioe) {
		ioe.printStackTrace();
	   } catch (SAXException sae) {
		sae.printStackTrace();
	   }
	}
}
