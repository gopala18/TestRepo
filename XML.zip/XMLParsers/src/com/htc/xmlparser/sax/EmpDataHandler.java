package com.htc.xmlparser.sax;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.helpers.DefaultHandler;

public class EmpDataHandler extends DefaultHandler{

	@Override
	public void characters(char[] data, int start, int length) throws SAXException {
		// TODO Auto-generated method stub
			//System.out.println(new String(data, start, length));
	}

	@Override
	public void endDocument() throws SAXException {
		// TODO Auto-generated method stub
		System.out.println("Parsing completed.");
	}

	@Override
	public void endElement(String uri, String lname, String qname)
			throws SAXException {
		// TODO Auto-generated method stub
		//System.out.println("/"+lname);
		System.out.println();
	}

	@Override
	public void error(SAXParseException se) throws SAXException {
		// TODO Auto-generated method stub
		System.out.println("Line:" + se.getLineNumber());
		System.out.println("Message:" + se.getMessage());

	}

	@Override
	public void fatalError(SAXParseException se) throws SAXException {
		// TODO Auto-generated method stub
		System.out.println("Line:" + se.getLineNumber());
		System.out.println("Message:" + se.getMessage());

	}

	@Override
	public void startDocument() throws SAXException {
		// TODO Auto-generated method stub
		System.out.println("Parsing XML document.");
	}

	@Override
	public void startElement(String uri, String lname, String qname,
			Attributes attrs) throws SAXException {
		// TODO Auto-generated method stub
		System.out.print(lname+": ");
		if(attrs!=null) {
		for(int i=0;i<attrs.getLength();i++){
			System.out.println("attri "+attrs.getLocalName(i) + "=" +attrs.getValue(i));
		}
		}
	}

	@Override
	public void warning(SAXParseException se) throws SAXException {
		// TODO Auto-generated method stub
		System.out.println("Line:" + se.getLineNumber());
		System.out.println("Message:" + se.getMessage());

	}

	
}
