package com.htc.xmlparser.sax;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.helpers.DefaultHandler;

public class EmpidHandler extends DefaultHandler{
	boolean empIdFlag = false;
	@Override
	public void startDocument() throws SAXException {
		// TODO Auto-generated method stub
		System.out.println("Parsing XML document.");
	}
	@Override
	public void endDocument() throws SAXException {
		// TODO Auto-generated method stub
		System.out.println("Parsing completed.");
	}

	@Override
	public void startElement(String uri, String lname, String qname,
			Attributes attrs) throws SAXException {
		// TODO Auto-generated method stub
		if(lname.equals("emp")) {
			if(attrs.getValue("empid").equals("e102")) {
				empIdFlag = true;
			}
		}
	}
	@Override
	public void characters(char[] data, int start, int length) throws SAXException {
		// TODO Auto-generated method stub
		if(empIdFlag)
			System.out.println(new String(data, start, length));
	}
	@Override
	public void endElement(String uri, String lname, String qname)
			throws SAXException {
		// TODO Auto-generated method stub
		if(lname.equals("emp")) 
				empIdFlag = false;
	}

	// Error handling
	public void fatalError(SAXParseException se) throws SAXException {
		// TODO Auto-generated method stub
		System.out.println("Line:" + se.getLineNumber());
		System.out.println("Message:" + se.getMessage());
	}
	@Override
	public void warning(SAXParseException se) throws SAXException {
		// TODO Auto-generated method stub
		System.out.println("Line:" + se.getLineNumber());
		System.out.println("Message:" + se.getMessage());

	}
	@Override
	public void error(SAXParseException se) throws SAXException {
		// TODO Auto-generated method stub
		System.out.println("Line:" + se.getLineNumber());
		System.out.println("Message:" + se.getMessage());

	}


}
