package com.htc.xmlparser.sax;

import java.io.IOException;

import javax.xml.XMLConstants;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.SAXException;

public class MySAXParser {

	public static void main(String[] args) {
		
		SAXParserFactory factory = SAXParserFactory.newInstance();
		factory.setValidating(true);
		factory.setNamespaceAware(true);
		try {
			factory.setFeature("http://apache.org/xml/features/validation/schema", true);
			
			SAXParser parser = factory.newSAXParser();
			parser.setProperty("http://java.sun.com/xml/jaxp/properties/schemaLanguage", XMLConstants.W3C_XML_SCHEMA_NS_URI);
			//parser.setProperty("http://java.sun.com/xml/jaxp/properties/schemaSource","emp.xsd");  

			parser.parse("9781849467162_ch02.xml", new EmpDataHandler());
			//parser.parse("emp.xml", new EmpidHandler());
			System.out.println("Parsed successfully");
		} catch (ParserConfigurationException | SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
