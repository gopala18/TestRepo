import java.io.File;
import java.io.FileOutputStream;

import org.wiztools.xsdgen.XsdGen;
import org.wiztools.xsdgen.XsdGenMain;


public class Main {

	public static void main(String[] args) {
		
		XsdGen
		
		gen.parse(new File("in.xml"));
		File out = new File("out.xsd");
		gen.write(new FileOutputStream(out));
	}
}
