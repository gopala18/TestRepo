package com.htc.students;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table (name="Student")
@NamedQueries({
	@NamedQuery(name="getbyid", query="select st from Students st where regNo=?")
})
public class Students {
	@Id
	@Column
	private String regNo;
	@Column
	private String name;
	@Column
	private int age;
	
	public Students() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Students(String regNo, String name, int age) {
		super();
		this.regNo = regNo;
		this.name = name;
		this.age = age;
	}
	public String getRegNo() {
		return regNo;
	}
	public void setRegNo(String regNo) {
		this.regNo = regNo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	@Override
	public String toString() {
		return "Students [regNo=" + regNo + ", name=" + name + ", age=" + age + "]";
	}
	
	
}
