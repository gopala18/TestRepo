package com.htc.students;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.htc.university.dto.StudentResult;

public class ResultDAOJPAImpl implements ResultDAO{

	@Override
	public boolean insertResult(String regno, int mark1, int mark2, int mark3,
			int mark4, int mark5) {
		// TODO Auto-generated method stub
		boolean result =false;

		return result;
	}

	@Override
	public StudentResult getResult(String regno) {
		// TODO Auto-generated method stub
		StudentResult result = null;
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("mydb");
		EntityManager em = factory.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		try {
			result = em.find(StudentResult.class, regno);
			tx.commit();
			
		}
		catch(Exception e) {
			tx.rollback();
			e.printStackTrace();
		}

		return result;
	}

	@Override
	public boolean insertResult(StudentResult result) {
		// TODO Auto-generated method stub
	boolean status =false;
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("mydb");
		EntityManager em = factory.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		try {
			em.persist(result);
			tx.commit();
			status = true;
		}
		catch(Exception e) {
			tx.rollback();
			e.printStackTrace();
		}
		factory.close();
	return status;

	}

}
