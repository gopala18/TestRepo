package com.htc.students;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name="RESULTS")
@NamedQueries({
	@NamedQuery(name="findByMarks",query="select sr from StudentResult sr where sr.mark1 > :mark and sr.mark2 > :mark and sr.mark3 > :mark and sr.mark4 > :mark and sr.mark5 > :mark"),
	@NamedQuery(name="findBySub1",query="select sr from StudentResult sr where sr.mark1 > :mark"),
})
public class StudentResult implements Serializable{

	
	private String regno;
	private int mark1;
	private int mark2;
	private int mark3;
	private int mark4;
	private int mark5;
	
	public StudentResult(){}

	public StudentResult(String regno, int mark1, int mark2, int mark3,
			int mark4, int mark5) {
		super();
		this.regno = regno;
		this.mark1 = mark1;
		this.mark2 = mark2;
		this.mark3 = mark3;
		this.mark4 = mark4;
		this.mark5 = mark5;
	}
	@Id
	@Column(name="REGNO")
	public String getRegno() {
		return regno;
	}

	public void setRegno(String regno) {
		this.regno = regno;
	}
	@Column(name="SUB1")
	public int getMark1() {
		return mark1;
	}

	public void setMark1(int mark1) {
		this.mark1 = mark1;
	}
	@Column(name="SUB2")
	public int getMark2() {
		return mark2;
	}

	public void setMark2(int mark2) {
		this.mark2 = mark2;
	}
	@Column(name="SUB3")
	public int getMark3() {
		return mark3;
	}

	public void setMark3(int mark3) {
		this.mark3 = mark3;
	}
	@Column(name="SUB4")
	public int getMark4() {
		return mark4;
	}

	public void setMark4(int mark4) {
		this.mark4 = mark4;
	}
	@Column(name="SUB5")
	public int getMark5() {
		return mark5;
	}

	public void setMark5(int mark5) {
		this.mark5 = mark5;
	}
	
}
