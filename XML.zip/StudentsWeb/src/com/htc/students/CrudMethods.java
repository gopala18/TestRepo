package com.htc.students;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class CrudMethods {
	public boolean insertstudent(String regNo,String name,int age){
		boolean result=false;
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("mydb");
		EntityManager em = factory.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		try {
			result = em.find(Students.class, regNo);
			tx.commit();
			
		}
		catch(Exception e) {
			tx.rollback();
			e.printStackTrace();
		}
return result;

	}
}
