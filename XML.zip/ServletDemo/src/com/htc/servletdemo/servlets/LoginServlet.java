package com.htc.servletdemo.servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/loginServlet")
public class LoginServlet extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		if (req.getParameter("userName").equals("gopim") && req.getParameter("password").equals("123")) { 
			HttpSession session=req.getSession();
			session.setAttribute("userName", req.getParameter("userName"));
			req.getRequestDispatcher("homeServlet").forward(req, resp);
		}else
			resp.getWriter().println("<font color='red'>Invalid User name or password</font>");
			req.getRequestDispatcher("./index.html").include(req, resp);
		
	}

}
