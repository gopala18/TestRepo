{
'name':'controllersdemo',
'version':'1.0',
'description':'Constrollers Demo',
'depends':['base'],
'installable':True,
'data':['views/employee_view.xml','views/templates.xml'],
'qweb':['static/src/xml/templates.xml'],
}