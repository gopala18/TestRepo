from openerp.osv import fields,osv
import logging
import xlwt
#import xlrd
class controllersdemo_employees(osv.Model):
    _name='controllersdemo.employees'
    _description="Employees"
    _columns={
              'employee_name':fields.char('Employee Name',size=100,required=True),
              }
    def getEmployees(self,cr,uid,context=None):
        cr.execute("""SELECT employee_name FROM controllersdemo_employees""")
        employees=[]
        for record in cr.fetchall():
            employees.append({'employee_name':record[0]})
        return employees
    def writeExcel(self,cr,uid,context=None):
        book=xlwt.Workbook()
        sheet1=book.add_sheet("employees_sheet")
        fmt = xlwt.Style.easyxf("""
    font: name Arial;
    borders: left thick, right thick, top thick, bottom thick;
    pattern: pattern solid, fore_colour red;
    """, num_format_str='YYYY-MM-DD')
        sheet1.write(0,0,"Name of the Employees",fmt)
        cr.execute("""SELECT employee_name FROM controllersdemo_employees""")
        index=1
        for record in cr.fetchall():
            sheet1.write(index,0,record[0],fmt)
            index=index+1
        book.save("sample.xls")
        return True
    '''def readExcel(self,cr,uid,context=None):
        book=xlrd.open_workbook("d:\\dept.xls")
        for sheet_name in book.sheet_names():
            logging.info(sheet_name)
            sheet = book.sheet_by_name(sheet_name)
            data=[]
            index=0
            for rows in range(sheet.nrows):
                list={}
                for cols in range(sheet.ncols):
                    list.update({rows:(sheet.cell(rows,cols).value)})                
            data.append(list)
        return data'''