from openerp import http
from openerp.http import Controller,route,request
import logging

class demo(Controller):
    _name="controllersdemo.demo"
    _description="constrollers demo"
    @route("/set2/",auth="none")
    def set2(self):
        cr=request.cr
        #cr=request.registry["controllersdemo.employees"]
        cr.execute("""SELECT employee_name FROM controllersdemo_employees""")
        employees=[]
        for record in cr.fetchall():
            employees.append({'employee_name':record[0]})
        logging.info(employees)
        return request.render("controllersdemo.employee_template",{'employees_list':employees})
    @route("/set24/",auth="none")		
    def set24(self):
       return "<h1>Sample Page</h1>"

