openerp.controllersdemo=function(instance){
	var qweb=instance.web.qweb;
	instance.controllersdemo.home=instance.web.Widget.extend({
		events:{
			"click #excel_write":"excelWrite",
			"click #excel_read":"excelRead",
		},
		start:function(){
			var self=this;
			var model=new instance.web.Model("controllersdemo.employees");
			console.log("testing")
			model.call("getEmployees",[],{context:new instance.web.CompoundContext()})
			.then(function(result){
				console.log(result);
				self.$el.append(qweb.render("employees",{employees_list:result}));
			});
		},
		excelWrite:function(){
			var model=new instance.web.Model("controllersdemo.employees");
			model.call("writeExcel",[],{context:new instance.web.CompoundContext()})
			.then(function(result){
				if(result)
					alert("Records written successfully into excel");
				else
					alert("Records not written into excel");
			});
		},
		excelRead:function(){
			var self=this;
			var model=new instance.web.Model("controllersdemo.employees");
			model.call("readExcel",[],{context:new instance.web.CompoundContext()})
			.then(function(result){
				console.log(result);
			});
		},
	});
	instance.web.client_actions.add('employee.tag','instance.controllersdemo.home');
}