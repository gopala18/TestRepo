from openerp.osv import fields, osv
import logging
class qweb_department(osv.Model):
    _name="qweb.department"
    _description="Department Details"
    _rec_name="department_name"
    _columns={
              'department_number':fields.one2many('qwebdemo.employee','employee_department_number','Employee Details'),
              'department_name':fields.char('Department Name',size=60,required=True),
              }
    def get_department_names(self,cr,uid,val,context=None):
        record=self.browse(cr,uid,val,context)
        return record.department_name
class qweb_employee(osv.Model):
    _name="qweb.employee"
    _description="Employee Details"
    _columns={
              'employee_number':fields.char('Employee Number',size=20,required=True),
              'employee_name':fields.char('Employee Name',size=60,required=True),
              'image':fields.binary("Employee Image"),
              'employee_department_number':fields.many2one('qweb.department','Department Details')
              }
    def write(self,cr,uid,ids,vals,context=None):
        logging.info("WRITE")
        logging.info(vals)
        return super(qweb_employee,self).write(cr,uid,ids,vals,context=context)
    def get_department_names(self,cr,uid,context=None):
        cr.execute("SELECT id,department_name FROM qweb_department")
        records=cr.fetchall()
        logging.info(records)
        return records
    def create(self,cr,uid,vals,context=None):
        logging.info(vals)
        return super(qweb_employee,self).create(cr,uid,vals,context)
    def get_employees(self,cr,uid,selectedDepartment,context=None):
        cr.execute("SELECT id,employee_number,employee_name FROM qweb_employee WHERE employee_department_number=%s",(selectedDepartment,))
        list=[]
        for record in cr.fetchall():
            dict={}
            dict['id']=record[0]
            dict['employee_number']=record[1]
            dict['employee_name']=record[2]
            list.append(dict)
        logging.info("PYTHON CALL")
        return list
        