{
    'name':'Qweb',
    'description':"""QWEB Demonstartion""",
    'version':'1.0',
    'author':'deepa',
    'installable':True,
    'depends':['base'],
    'data':['qweb_view.xml','security/qweb_security.xml','wizard/schedule_meeting_view.xml'],
    'js':['static/src/js/qweb_javascript.js'],
    'qweb':['static/src/xml/qweb_template.xml'],
    'css':['static/src/css/qweb_css.css']
}