openerp.qweb=function(instance){
	/*var _t = instance.web._t,
	_lt = instance.web._lt;*/
	var qweb=instance.web.qweb;
	//instance.qweb={};
	instance.qweb.department=instance.web.Widget.extend({
		start:function(){
			var self=this;
			var departmentObject=new instance.web.Model("qweb.department");
			departmentObject.call("get_department_names",[1],{context:new instance.web.CompoundContext()})
			.then(function(result){
				self.$el.append(qweb.render("department",{name:result}));
			});
		},
		
	});
	instance.web.client_actions.add('department.tag','instance.qweb.department');
	
	instance.qweb.employee=instance.web.Widget.extend({
		events:{
			'click #Insertid':'create'
			
		},
		start:function(){
			var self=this;
			var employeeObject=new instance.web.Model("qweb.employee");
			employeeObject.call("get_department_names",[],{context:new instance.web.CompoundContext()})
			.then(function(result){
				$("#departmentselect").append($("<option>").val("0").html("--Select Any Department--"));
				$.each(result,function(key,value){
					$("#departmentselect").append($("<option/>").val(value[0]).html(value[1]));
				});
			});
			self.$el.append(qweb.render("employee"));
		},
		create:function(){
			var employeeObject=new instance.web.Model("qweb.employee");
			var emp={
					'employee_number':$("#employeeid").val(),
					'employee_name':$("#employeenameid").val(),
					'employee_department_number':$("#departmentselect").val()
			};
			alert(emp);
			console.log(emp);
			employeeObject.call("create",[emp],{context:new instance.web.CompoundContext()})
			.then(function(result){
				if(result)
					alert("record inserted successfully");
				else
					alert("record insertion failed");
			});
		},
	});
	
	instance.web.client_actions.add('employee.tag','instance.qweb.employee');
	
	instance.qweb.displayemployee=instance.web.Widget.extend({
		events:{
			'click #getdetailsid':'getEmployeeDetails',
			'click .trclass':'editRecord',
			'change #departmentselection':'check',
			'mouseleave #getdetailsid':'check',
		},
		start:function(){
			var self=this;
			var getDepartment=new instance.web.Model("qweb.employee");
			getDepartment.call("get_department_names",[],{context:new instance.web.CompoundContext()})
			.then(function(result){
				$("#departmentselection").append($("<option>").val("0").html("--Select Any Department--"));
				$.each(result,function(key,value){
					$("#departmentselection").append($("<option/>").val(value[0]).html(value[1]));
				});
			});
			self.$el.append(qweb.render("employees_department"));
		},
		getEmployeeDetails:function(){
			var self=this;
			$("#divid").empty();
			var selectedDepartment=$("#departmentselection").val();
			var getEmployees=new instance.web.Model("qweb.employee");
			getEmployees.call("get_employees",[selectedDepartment],{context:new instance.web.CompoundContext()})
			.then(function(result){
				console.log(result);
				self.$el.append(qweb.render("emp_dept",{employees:result}));
			});
		},
		editRecord:function(instance){
			var self=this;
			var id=instance.currentTarget.getAttribute("value");
			var context = {
		            'id': this.id,
		        };
			var action = {
	                type: 'ir.actions.act_window',
	                res_model: 'qweb.employee',
	                res_id:parseInt(id),
	                view_mode:'form',
	                view_type:'form',
	                views: [[false, 'form']],
	                target:'current',
	                context: context,
				};
			self.do_action(action);
		},
		check:function(){
			
		},
	});
    instance.web.client_actions.add('displayemployee.tag','instance.qweb.displayemployee');
}
