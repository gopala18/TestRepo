from openerp.osv import fields, osv
import logging
class qweb_meeting(osv.TransientModel):
    _name="qweb.meeting"
    _description="Meeting"
    _columns={
              'name':fields.char('Name',size=60,required=True),
              }
    def default_get(self,cr,uid,fields,context=None):
        record_id=context.get('active_id',False)
        #if record_id:
        record=self.pool.get('qweb.employee').browse(cr,uid,record_id,context=context)
        result=super(qweb_meeting,self).default_get(cr,uid,fields,context=context)
        result.update({'name':record['employee_name']})
        return result