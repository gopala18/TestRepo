from openerp.osv import fields, osv
class category(osv.Model):
    _name='category'
    _description="""Category Details"""
    _columns={
              'category_code':fields.char('CategoryCode',size=20,required=True),
              'category_name':fields.char('CategoryName',size=20,required=True),
              }