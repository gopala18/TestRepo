from openerp.osv import fields, osv
class category(osv.Model):
    _name='category'
    _description="""Category Details"""
    _columns={
              'category_ref':fields.one2many('product','product_category_code','CategoryCode'),
			  'category_code':fields.char('CategoryCode',size=20,required=True),
              'category_name':fields.char('CategoryName',size=20,required=True),
              }
class product(osv.Model):
    _name='product'
    _description="""Product Details"""
    _columns={
              'product_category_code':fields.many2one('category','CategoryCode'),
              'product_code':fields.char('ProductCode',size=20,required=True),
              'product_name':fields.char('ProductName',size=20,required=True),
              }