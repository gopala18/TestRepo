{
'name':'Category',
'author':'deepa',
'version':'1.0',
'description':"""
Category Details
""",
'depends':['base'],
'installable':True,
'data':['category_view.xml'],
}