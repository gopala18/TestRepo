openerp.qwebdemo=function(instance){
	
	var qweb=instance.web.qweb;
	//instance.qwebdemo={};
	instance.qwebdemo.department=instance.web.Widget.extend(
			{
		start:function(){
			var self=this;
			var departmentObject=new instance.web.Model("qwebdemo.department");
			departmentObject.call("get_department_names",[1],{context:new instance.web.CompoundContext()})
			.then(function(result){
				self.$el.append(qweb.render("department",{name:result}));
			});
		},
	}
);
	instance.web.client_actions.add('department.tag','instance.qwebdemo.department');
	
	instance.qwebdemo.employee=instance.web.Widget.extend({
		events:{
			'click #Insertid':'create'
		},
		start:function(){
			var self=this;
			var employeeObject=new instance.web.Model("qwebdemo.employee");
			employeeObject.call("get_department_names",[],{context:new instance.web.CompoundContext()})
			.then(function(result){
				$("#departmentselect").append($("<option>").val("0").html("--Select Any Department--"));
				$.each(result,function(key,value){
					$("#departmentselect").append($("<option/>").val(value[0]).html(value[1]));
				});
			});
			self.$el.append(qweb.render("employee"));
		},
		create:function(){
			var employeeObject=new instance.web.Model("qwebdemo.employee");
			var emp={
					'employee_number':$("#employeeid").val(),
					'employee_name':$("#employeenameid").val(),
					'employee_department_number':$("#departmentselect").val()
			};
			alert(emp);
			console.log(emp);
			employeeObject.call("create",[emp],{context:new instance.web.CompoundContext()})
			.then(function(result){
				if(result)
					alert("record inserted successfully");
				else
					alert("record insertion failed");
			});
		},
	});
	
	instance.web.client_actions.add('employee.tag','instance.qwebdemo.employee');
	
	instance.qwebdemo.displayemployee=instance.web.Widget.extend({
		events:{
			'click #getdetailsid':'getEmployeeDetails',
			'click .emp_record':'getEmployeeRecord',
			//'change #departmentselection ':'getEmployeeDetails',
		},
		start:function(){
			var self=this;
			var getDepartment=new instance.web.Model("qwebdemo.employee");
			getDepartment.call("get_department_names",[],{context:new instance.web.CompoundContext()})
			.then(function(result){
				$("#departmentselection").append($("<option>").val("0").html("--Select Any Department--"));
				$.each(result,function(key,value){
					$("#departmentselection").append($("<option/>").val(value[0]).html(value[1]));
				});
			});
			self.$el.append(qweb.render("employees_department"));
		},
		getEmployeeDetails:function(){
			var self=this;
			$("#emp").empty();
			var selectedDepartment=$("#departmentselection").val();
			var getEmployees=new instance.web.Model("qwebdemo.employee");
			getEmployees.call("get_employees",[selectedDepartment],{context:new instance.web.CompoundContext()})
			.then(function(result){
				console.log(result);
				self.$el.append(qweb.render("display_employees",{employees:result}));
				$("#empdet").css({'background-color':'red','font-size': '30px'}).slideDown("slow");
			});
		},
		getEmployeeRecord:function(instance){
			var self=this;
			var employee_id=instance.currentTarget.getAttribute("empid");
			var action={
					'type':'ir.actions.act_window',
					'res_model':'qwebdemo.employee',
					'res_id':parseInt(employee_id),
					'view_mode':'form',
					'view_type':'form',
					'views':[[false,'form']],
					'view_id':'employee_form_view',
					'context':{},
					'target':'current',
			}
			/*var action={
					'type':'ir.actions.client',
					'tag':'employee.tag',
					'target':'new',
			}*/
			self.do_action(action);
		},
	});
    instance.web.client_actions.add('displayemployee.tag','instance.qwebdemo.displayemployee');
}
