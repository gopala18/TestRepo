{
    'name':'Qweb Demo',
    'description':"""QWEB Demonstartion""",
    'version':'1.0',
    'author':'deepa',
    'installable':True,
    'depends':['base'],
    'data':['qwebdemo_view.xml'],
    'js':['static/src/js/qwebdemo_javascript.js'],
    'qweb':['static/src/xml/qwebdemo_template.xml'],
    'css':['static/src/css/qwebdemo_css.css'],
}