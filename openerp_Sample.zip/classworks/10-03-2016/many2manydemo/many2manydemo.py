from openerp.osv import fields, osv
class faculty_personal_details(osv.Model):
    _name="faculty.personal.details"
    _description="""Faculty Personal Details"""
    _rec_name="faculty_name"
    _columns={
              #'faculty_code':fields.char('Faculty Code',size=20,required=True),
              'faculty_name':fields.char('Faculty Name',size=20,required=True),
              'faculty_skills_ref':fields.many2many('skills.sets','faculty_skills_sets','faculty_code','skill_code','Skills'),
              }
    
class skills_sets(osv.Model):
    _name="skills.sets"
    _description="""Skill sets"""
    _rec_name="skill_name"
    _columns={
              #'skill_code':fields.char('Skill Code',size=20,required=True),
              'skill_name':fields.char('Skill Name',size=20,required=True),
              'faculty_skills':fields.many2many('faculty.personal.details','faculty_skills_sets','skill_code','faculty_code','Skills'),
              }