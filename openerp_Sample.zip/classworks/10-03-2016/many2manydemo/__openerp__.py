{
'name':'FacultySkillSets',
'author':'deepa',
'version':'1.0',
'description':"""Faculty Skills""",
'depends':['base'],
'installable':True,
'data':['faculty_skills_view.xml'],
}