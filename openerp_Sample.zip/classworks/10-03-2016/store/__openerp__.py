{
'name':'CategoryDetails',
'author':'deepa',
'version':'1.0',
'description':"""
Category Details
""",
'depends':['base'],
'installable':True,
'data':['store_view.xml'],
}