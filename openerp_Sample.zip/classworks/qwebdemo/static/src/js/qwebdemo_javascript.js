openerp.qwebdemo=function(instance){
	
	var qweb=instance.web.qweb;
	//instance.qwebdemo={};
	instance.qwebdemo.department=instance.web.Widget.extend({
		start:function(){
			var self=this;
			var departmentObject=new instance.web.Model("qwebdemo.department");
			departmentObject.call("get_department_names",[1],{context:new instance.web.CompoundContext()})
			.then(function(result){
				self.$el.append(qweb.render("department",{name:result}));
			});
		},
		
	});
	instance.web.client_actions.add('department.tag','instance.qwebdemo.department');
	
	instance.qwebdemo.employee=instance.web.Widget.extend({
		events:{
			'click #Insertid':'create'
		},
		start:function(){
			var self=this;
			var employeeObject=new instance.web.Model("qwebdemo.employee");
			employeeObject.call("get_department_names",[],{context:new instance.web.CompoundContext()})
			.then(function(result){
				$("#departmentselect").append($("<option>").val("0").html("--Select Any Department--"));
				$.each(result,function(key,value){
					$("#departmentselect").append($("<option/>").val(value[0]).html(value[1]));
				});
			});
			self.$el.append(qweb.render("employee"));
		},
		create:function(){
			var employeeObject=new instance.web.Model("qwebdemo.employee");
			var emp={
					'employee_number':$("#employeeid").val(),
					'employee_name':$("#employeenameid").val(),
					'employee_department_number':$("#departmentselect").val()
			};
			alert(emp);
			console.log(emp);
			employeeObject.call("create",[emp],{context:new instance.web.CompoundContext()})
			.then(function(result){
				if(result)
					alert("record inserted successfully");
				else
					alert("record insertion failed");
			});
		},
	});
	
	instance.web.client_actions.add('employee.tag','instance.qwebdemo.employee');
}
