from openerp.osv import fields, osv
import logging
class qwebdemo_department(osv.Model):
    _name="qwebdemo.department"
    _description="Department Details"
    _rec_name="department_name"
    _columns={
              'department_number':fields.one2many('qwebdemo.employee','employee_department_number','Employee Details'),
              'department_name':fields.char('Department Name',size=60,required=True),
              }
    def get_department_names(self,cr,uid,val,context=None):
        record=self.browse(cr,uid,val,context)
        return record.department_name
class qwebdemo_employee(osv.Model):
    _name="qwebdemo.employee"
    _description="Employee Details"
    _columns={
              'employee_number':fields.char('Employee Number',size=20,required=True),
              'employee_name':fields.char('Employee Name',size=60,required=True),
              'employee_department_number':fields.many2one('qwebdemo.department','Department Details')
              }
    def get_department_names(self,cr,uid,context=None):
        cr.execute("SELECT id,department_name FROM qwebdemo_department")
        records=cr.fetchall()
        logging.info(records)
        return records
    def create(self,cr,uid,vals,context=None):
        logging.info(vals)
        return super(qwebdemo_employee,self).create(cr,uid,vals,context)
        