from openerp.osv import fields, osv
class category(osv.Model):
    _name='category'
    _description="""Category Details"""
    _rec_name="category_code"
    _columns={
              'category_ref':fields.one2many('product','product_category_code','ProductDetails'),
			  'category_code':fields.char('CategoryCode',size=20,required=True),
              'category_name':fields.char('CategoryName',size=20,required=True),
              }
class product(osv.Model):
    _name='product'
    _description="""Product Details"""
    _rec_name="product_name"
    _columns={
              'product_category_code':fields.many2one('category','CategoryDetails'),
              'product_code':fields.one2many('order.det','order_product_code','Order Details'),
              'product_name':fields.char('ProductName',size=20,required=True),
              'product_price':fields.integer('Price'),
              }
class order_det(osv.Model):
    _name='order.det'
    _description="""Order Details"""
    _columns={
              'order_code':fields.char('Order Code',size=20,required=True),
              'order_product_code':fields.many2one('product','Product Code'),
              'order_date':fields.date('Order Date'),
              'delivery_date':fields.date('Delivery Date'),
              'quantity':fields.integer('Quantity',required=True),
              'order_category_code':fields.related('order_product_code','product_category_code',type="many2one",relation="category",string="Category Code"),
              }