from openerp.osv import fields, osv


class category(osv.Model):
    _name='category'
    _description="""Category Details"""
    _rec_name="category_code"
    _columns={
              'category_ref':fields.one2many('product','product_category_code','ProductDetails'),
			  'category_code':fields.char('CategoryCode',size=20,required=True),
              'category_name':fields.char('CategoryName',size=20,required=True),
              }
class product(osv.Model):
    _name='product'
    _description="""Product Details"""
    _rec_name="product_name"
    _columns={
              'product_category_code':fields.many2one('category','CategoryDetails'),
              'product_code':fields.one2many('order.det','order_product_code','Order Details'),
              'product_name':fields.char('ProductName',size=20,required=True),
              'product_price':fields.integer('Price'),
              }
    _order='product_name'
    def create(self,cr,uid,vals,context=None):
        new_vals={'product_category_code':vals['product_category_code'],'product_name':vals['product_name']+'AA','product_price':vals['product_price']+1000}
        return super(product,self).create(cr,uid,new_vals,context)
    '''def read(self,cr,uid,ids,fields=None,context=None):
        return super(product,self).read(cr,uid,ids,fields={'product_category_code','product_code','product_name','product_price'},context=context)'''
    def write(self,cr,uid,ids,vals,context=None):
        new_vals={'product_name':vals['product_name']+'BB','product_price':vals['product_price']+1000}
        return super(product,self).write(cr,uid,ids,new_vals,context)
    def unlink(self,cr,uid,ids,context=None):
        return super(product,self).unlink(cr,uid,ids,context)
    def onChange_Price(self,cr,uid,ids,context=None):
        records=self.browse(cr,uid,ids,context)
        value=0
        for record in records:
            if(record.id==ids[0]):
                value=record.product_price+1000
        return {'value':{'product_price':value,'product_name':'Toshiba'}}
class order_det(osv.Model):
    _name='order.det'
    _description="""Order Details"""
    def calc_total(self,cr,uid,ids,field_name,arg,context=None):
        result={}
        #result[1]=400
        #result[2]=700
        for record in self.browse(cr,uid,ids):
            result[record.id]=record.quantity*record.order_product_code.product_price
        return result
        
    '''def get_total(self,cr,uid,ids,product_code,quantity,context=None):
        #ids=self.pool.get('product').search(cr,uid,[('product_code','=',product_code)],count=True)
        records=self.browse(cr,uid,ids[0],context=context)
        
        return {'value':{'total':records.order_product_code.product_price*quantity}}'''
    selection_list=[('cash','Cash On Delivery'),('online','Online Payment')]       
    _columns={
              'order_code':fields.char('Order Code',size=20,readonly=True),
              'order_product_code':fields.many2one('product','Product Code'),
              'order_date':fields.date('Order Date'),
              'delivery_date':fields.date('Delivery Date'),
              'quantity':fields.integer('Quantity',required=True),
              'order_category_code':fields.related('order_product_code','product_category_code',type="many2one",relation="category",string="Category Code"),
              #'total':fields.float('Total'),
              'total':fields.function(calc_total,type='integer',string='Total',store=True),
              'Payment_mode':fields.selection(selection_list,'Select your mode of payment')
              }
    _defaults={
               'order_code':lambda self,cr,uid,context: self.pool.get('ir.sequence').get(cr,uid,'OrderSequence',context)
               }
    '''def create(self,cr,uid,vals,context=None):
        vals['order_code']=self.pool.get('ir.sequence').get(cr,uid,'OrderSequence',context)
        return super(order_det,self).create(cr,uid,vals,context)'''
        