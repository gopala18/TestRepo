from openerp.osv import fields,osv
#mdsanfjsdf