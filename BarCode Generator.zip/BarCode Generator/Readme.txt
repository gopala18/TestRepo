				BarCodeGen 


URL to access your project after deploying in tomcat server
copy the war file into the webapps directory of tomcat server and start the server

Login Page: http://localhost:8080/BarCodeGen/

Barcode Generate: http://localhost:8080/BarCodeGen/BarCodeGen.jsp

Search Barcode: http://localhost:8080/BarCodeGen/SearchBarCode.jsp

