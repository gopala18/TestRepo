package com.htc.main;

import java.util.ArrayList;
import java.util.List;

import org.testng.TestNG;
import org.testng.xml.XmlClass;
import org.testng.xml.XmlInclude;
import org.testng.xml.XmlSuite;
import org.testng.xml.XmlTest;
import org.testng.xml.XmlSuite.ParallelMode;

import com.htc.utils.PropertiesReader;
import com.htc.utils.ExcelReader;


public class Main {

	public static void main(String[] args) {
		XmlSuite suite = new XmlSuite();
		XmlTest test = new XmlTest(suite);
		List<XmlClass> classes = new ArrayList<XmlClass>();
		List<XmlSuite> suites = new ArrayList<XmlSuite>();

		TestNG tng = new TestNG();
		
		

		suite.setName("AutomationTesting");

		
		suite.setParallel(ParallelMode.CLASSES);
		test.setName(PropertiesReader.read("testName"));
		
		Object[][] testConfig = ExcelReader.read(PropertiesReader.read("testConfigFile"),
				PropertiesReader.read("testConfigSheet"));

		
		for (Object[] data : testConfig) {
			XmlClass testClass = new XmlClass((String) data[0]);

			List<XmlInclude> includes = new ArrayList<XmlInclude>();
			for (int colIndex = 1; colIndex < data.length; colIndex++) {
				if((String) data[colIndex]!=null)
					includes.add(new XmlInclude((String) data[colIndex]));
				System.out.println(data[colIndex]);
				
			}

			testClass.setIncludedMethods(includes);
			classes.add(testClass);

		}

		test.setXmlClasses(classes);
		//suite.addTest(test);
		suites.add(suite);
		
		if(tng!=null)
		{
			System.out.println("Good");}
		tng.setXmlSuites(suites);
		tng.run();

	}

}