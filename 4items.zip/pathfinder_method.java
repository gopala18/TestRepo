package com.htc.testing.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Iterator;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.google.common.io.Files;

public class PathFinder {

	public static ArrayList<String> findFilePath(String directoryName) {
		
        ArrayList<String> files=new ArrayList<>();
		File directory = new File(directoryName);
        // get all the files from a directory
        File[] fList = directory.listFiles();
        for (File file : fList) {
            if (file.isFile()) {
            	
                files.add(file.getAbsolutePath());
            } else if (file.isDirectory()) {
            	findFilePath(file.getAbsolutePath());
            }
        }
        return files;
    }
	public static boolean  updateResumePath(String fileName, String sheetName) {
		fileName="./data/"+fileName;
		boolean updateFlag=false;
		ArrayList<String> resumeFilesPath=PathFinder.findFilePath("./data/"+PropertiesReader.read("resumeDirectory"));
		for(String path:resumeFilesPath)
			System.out.println("path:"+path);
		Workbook workbook = null;
		try {
			FileInputStream file = new FileInputStream(new File(fileName));

			if (fileName.endsWith("xls")) {
				workbook = new HSSFWorkbook(file);
			} else if (fileName.endsWith("xlsx")) {
				workbook = new XSSFWorkbook(file);
			} else {
				throw new UnsupportedEncodingException("File format not supported: Please use xls or xlsx format.");
			}
			
			Sheet sheet = workbook.getSheet(sheetName);
			int maxRow=sheet.getPhysicalNumberOfRows();
			int maxCol = sheet.getRow(0).getPhysicalNumberOfCells();
			Iterator<Row> rowIterator = sheet.iterator();
			
			Iterator<String> resumes=resumeFilesPath.iterator();
			System.out.println("Max row and col:"+maxRow+":"+maxCol);
			while (rowIterator.hasNext() && resumes.hasNext()) {
				Row row = rowIterator.next();
				Cell cell=row.createCell(2);
				cell.setCellValue(resumes.next());
			}
			System.out.println("Max row and col:"+maxRow+":"+sheet.getRow(0).getPhysicalNumberOfCells());
			file.close();
			FileOutputStream out = new FileOutputStream(new File(fileName));
            workbook.write(out);
            workbook.close();
			out.close();
			if(sheet.getRow(0).getPhysicalNumberOfCells()> maxCol) 
				updateFlag=true;
				
			
		}
		catch(Exception e) {
			e.printStackTrace();
			
		}
		return updateFlag;
	}
}
