package com.htc.testing.utils;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class PropertiesReader {

	public static String read(String propertyKey) {
		String propertyValue = null;
		Properties prop = new Properties();
		
		try {
			prop.load(new FileInputStream("./config/ApplicationConfig.properties"));
			System.out.println("Property Reader Initiated...");
		} catch (IOException e) {
			try {
				prop.load(new FileInputStream("../config/ApplicationConfig.properties"));
			} catch (IOException e1) {
				
				System.out.println("Unable to locate Property file: "+e.getMessage());
			}
			
		}
		propertyValue = prop.getProperty(propertyKey);
		
		System.out.println("Property Read completed.");
		return propertyValue;
	}
}
