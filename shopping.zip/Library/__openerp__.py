{
    'name': 'Library',
    'author': 'Gopi',
    'version': '1.0',
    'depends': ['base'],
    'category' : 'Tools',
    'summary': 'Library Management System',
    'description': """
Library Management System
-------------------------
	Books Management
	Members Management
	Transactions Management
    """,
    'data': ['library_view.xml'],
    'installable': True,
    'auto-install' : False,
}
