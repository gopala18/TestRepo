from osv import osv,fields
from datetime import date

class library_books(osv.Model):
    _name='library.books'
    _description='Books class'
    _rec_name='bookID'
    _columns={
        'bookID' : fields.char('BookID',required=True,size=4),
        'title' : fields.char('Title',required=True,size=30),
        'book_category' : fields.char('Category',required=True,size=20),
        'copies' : fields.integer('Copies',required=True),
        'author_ID' : fields.many2one('library.authors','AuthorID',required=True),
        'publisher_ID' : fields.many2one('library.publishers','PublisherID',required=True),
        'edition' : fields.integer('Edition',required=True),
        'published_year' : fields.integer('Published year',required=True),
        'price' : fields.float('Price',digits=(10,2),required=True),
        'rack_no' : fields.integer('Rack number',required=True)
    }
    _sql_constraints=[('library_books_bookID_uk','unique(bookID)','BookID cannot be duplicated')]
   # _constraints=[(_check_publishedYear, 'published year cannot be future year', ['published_year'])]
    _default={}
"""	
    def _check_publishedYear(self, cr, userid, ids,context=None):
        for obj in self.browse(cr,userid,ids,context=context):
            year=datetime.year();
            pubyear=obj.published_year
    	    if pubyear > year:
    	        return False
        return True
"""		
class library_authors(osv.Model):
    _name='library.authors'
    _description='Authors class'
    _rec_name='authorID'
    _columns={
        'authorID' : fields.char('AuthorID',required=True,size=4),
        'author_name' : fields.char('Author Name',required=True,size=30),
        
    }
    _sql_constraints=[('library_authors_authorID_uk','unique(authorID)','AuthorID cannot be duplicated')]

class library_publishers(osv.Model):
    _name='library.publishers'
    _description='Publishers class'
    _rec_name='publisherID'
    _columns={
        'publisherID' : fields.char('PublisherID',required=True,size=4),
        'publisher_name' : fields.char('Publisher Name',required=True,size=30),
        'publisher_address' : fields.char('Publisher Address',required=True,size=40),
        
    }
    _sql_constraints=[('library_publishers_publisherID_uk','unique(publisherID)','publisherID cannot be duplicated')]
	
class library_members(osv.Model):
    def _check_joindate(self, cr, userid, ids, context=None):
        for obj in self.browse(cr,userid,ids,context=context):
            inputdate = obj.member_st_date
            todaydt = datetime.today();
            joindt = datetime.strptime(inputdate,'%Y-%m-%d')
            if joindt > todaydt: 
                return False
        return True
    _name='library.members'
    _description='Members class'
    _rec_name='memberID'
    _columns={
        'memberID' : fields.char('MemberID',required=True,size=4),
        'member_name' : fields.char('Member Name', required=True,size=30),
        'member_dept' : fields.char('Member Dept',required=True,size=20),
        'member_st_date' : fields.date('Membership Date'),
        'status' : fields.char('Status',required=True,size=20)
	}
    _sql_constraints=[('library_members_memberID_uk','unique(memberID)','MemberID cannot be duplicated')]
    _constraints = [(_check_joindate, 'Membership_Date cannot be future date', ['member_st_date'])]
	
class library_transactions(osv.Model):
    _name='library.transactions'
    _description='Book Transactions class'
    _columns={
        'bookID' : fields.many2one('library.books','BookID',required=True),
        'memberID' : fields.many2one('library.members','MemberID',required=True),
        'issueDate' : fields.date('IssueDate'),
        'dueDate' : fields.date('DueDate'),
        'returnDate' : fields.date('ReturnDate')
    }
