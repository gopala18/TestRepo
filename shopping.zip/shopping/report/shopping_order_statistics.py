from openerp.osv import osv, fields

class shopping_order_statistics(osv.Model):
	_name = 'shopping.order.statistics'
	_description = 'Shopping Order Statitics'
	_auto = False
	_columns = {
		'orderdate' :  fields.date('Order Date'),
		'total_no_of_orders' : fields.integer('Total Orders'),
		'day_total' : fields.float('Day Total',digits=(9,2))
	}
	_order = 'orderdate'
	
	
	def init(self, cr):
		cr.execute("""
			create or replace view shopping_order_statistics as (
				select 
						min(id) as id,
						orderdate, 
						count(*)  as total_no_of_orders,
						sum(ordervalue) as day_total
				from shopping_order  
				group by orderdate
			)
		""")
