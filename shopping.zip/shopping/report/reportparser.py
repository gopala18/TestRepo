from openerp.report import report_sxw
from openerp.osv import osv

class reportparser(report_sxw.rml_parse):
	def __init__(self, cr, userid, name,context):
		super(reportparser,self).__init__(cr,userid,name,context)

report_sxw.report_sxw('report.shopping.order','shopping.order','addons/shopping/report/order.rml',parser=reportparser,header=False)

class order_statistics_parser(report_sxw.rml_parse):

	def get_grand_total(self, objects):
		totalamount = 0.0
		for obj in objects:
			totalamount = totalamount + obj.day_total
		return totalamount
		
	def __init__(self, cr, userid, name,context):
		super(order_statistics_parser,self).__init__(cr,userid,name,context)
		self.localcontext.update({
			'get_grand_total' : self.get_grand_total
		})

report_sxw.report_sxw('report.shopping.order.statistics','shopping.order.statistics','addons/shopping/report/orderstatistics.rml',parser=order_statistics_parser,header=False)

