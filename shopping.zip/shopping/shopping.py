from osv import osv, fields

class shopping_product(osv.Model):
	_name = "shopping.product"
	_description = "Product"

	_columns = {
		'name' : fields.char('Product Name', size=20, required=True),
		'productdescription' : fields.text('Product Description'),
		'unitprice' : fields.float('Unit Price', digits=(7,2), required=True),
		'quantity_on_hand' : fields.integer('Quantity On Hand', required=True),
		'category_id' : fields.many2one('shopping.category', 'Category Name', required=True),
		'supplier_ids' : fields.many2many('shopping.supplier','rel_product_supplier', 'productname', 'suppliername','Supplier Name', required=True),
		'productimage' : fields.binary('Product Image')
	}
	
class shopping_category(osv.Model):
	_name = "shopping.category"
	_description = "Product Category"
	_columns = {
		'name' : fields.char('Category Name',size=20, required=True),
		'categorydescription' : fields.text('Category Descriptin')
	}

class shopping_supplier(osv.Model):
	_name = 'shopping.supplier'
	_description = "Product Supplier"

	_columns = {
		'name' : fields.char('Supplier Name',size=20, required=True),
		'supplieraddress': fields.text('Supplier Address'),
		'contactno' : fields.char('Contact No', size=15, required=True),
		'contactperson' : fields.char('Contact Person',size=30, required=True)
	}
	
class shopping_customer(osv.Model):
	_name = 'shopping.customer'
	_description = 'Customers'
	_columns = {
		'name' : fields.char('Customer Name', size=20, required=True),
		'shippingaddress' : fields.text('Shipping Addres'),
		'billingaddress' : fields.text('Billing Address'),
		'contactno' : fields.char('Contact No', size=15, required=True),
		'contactperson' : fields.char('Contact Person', size=30, required=True)
	}

class shopping_order(osv.Model):
	_name = 'shopping.order'
	_description = 'Shopping Order'

	def print_shopping_order(self, cr, userid, ids, context=None):
		return {
			'type' : 'ir.actions.report.xml',
			'report_name' : 'shopping.order',
			'datas' : {
				'model' : 'shopping.order',
				'ids' :ids
			}
		}
	
	def process_order(self, cr, userid, ids, context=None):
		""" Update the order state when user clicks on (Tick) Symbol """
		for order_ref in self.browse(cr, userid, ids, context=context):
			order_ref.write({'state':'confirm'},context=context)
		return True

	def cancel_order(self, cr, userid, ids, context=None):
		""" Cancel the order """
		self.unlink(cr, userid, ids, context=context)
		return True
		
	def _get_order_total(self, cr, userid, ids, name, arg, context=None):
		""" Returns the total order value of the given order """
		result = dict.fromkeys(ids, 0)
		order_ref = self.browse(cr,userid,ids,context=context)
		
		for order in order_ref:
			total = 0.0
			for orderline in order.order_item_ids:
				total = total + orderline.price
			result[order.id] = total
		return result
		
	def onchange_total(self, cr, userid, ids, order_item_ids, context=None):
		""" Calcualat the order total and update the view """
		order_line_prices = self.resolve_o2m_commands_to_record_dicts(cr, userid, "order_item_ids",order_item_ids,['price'],context=context)
		total = 0.0
		for order_line_price in order_line_prices:
			total = total + order_line_price['price']
		return {'value' : {'ordervalue' : total}}
		
		
	_columns = {
		'orderdate' : fields.date('Order Date', required=True, readonly=True, states = {'new':[('readonly' , False)]}),
		'customername': fields.many2one('shopping.customer','Customer Name',required=True, readonly=True, states = {'new':[('readonly' , False)]}),
		'state' : fields.selection([('new','New'),('confirm','Confirmed'),('cancelled','Cancelled')]),
		'order_item_ids' :fields.one2many('shopping.order.item','orderid','Order Items',readonly=True, states={'new' :[('readonly',False)]}, ondelete='cascade' ),
		'ordervalue' : 	fields.function(_get_order_total, type='float', string='Order Total',store=True)	
	}
	_defaults = {
		'orderdate' : fields.date.context_today,
		'state' : 'new'
	}	

class shopping_order_item(osv.Model):

	def onchange_productid(self, cr, uid, ids, product_id, qty_ordered, context=None):
		""" Get the price when product id changes """ 
		if product_id:
			product_ref = self.pool.get('shopping.product')
			if qty_ordered > 0:
				productobj = product_ref.browse(cr, uid, product_id,context=context);
				linetotal = qty_ordered * productobj.unitprice
				result = {'value' : {'price' : linetotal}}
			else:
				result = {'value' : {'price' : 0.0,}, 
						  'warning' : {'title':'Quantity', 'message' :'Invalid Quantity'}}
			return result
		return {'value' : {'price' : 0.0}}
		
	
	_name = 'shopping.order.item'
	_description = 'Ordered Item'
	_rec_name = 'product_id'
	_columns = {
		'product_id' : fields.many2one('shopping.product', 'ProductName',required=True),
		'orderid' : fields.many2one('shopping.order', 'OrderId', required=True, ondelete='cascade'),
		'qty_ordered' : fields.integer('Quantity',required=True),
		'price' : fields.float('Price', digits=(7,2), required=True)
		#'suppliername':  fields.related('productname','supplier_ids',type='many2many',relation='shopping.supplier', string='Supplier')
	}
	_defaults = {
		'qty_ordered' : 1
	}