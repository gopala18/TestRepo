{
    'name': 'Shopping',
    'author': 'Ansh Kumar',
    'version': '1.0',
    'depends': ['base'],
    'category' : 'Tools',
    'summary': 'Shopping Cart Application',
    'description': """
		Shopping Cart Application
    """,
    'data': ['shopping_view.xml','shopping_report.xml',],
	'css' : ['static/src/css/style.css'],
	'qweb':['static/src/xml/custom.xml'],
    'installable': True,
    'auto-install' : True,
}
