{
    'name': 'HRMS',
    'author': 'Ansh Kumar',
    'version': '1.0',
    'depends': ['base'],
    'category' : 'Tools',
    'summary': 'Human Resource Management',
    'description': """
Human Resource Management System
--------------------------------
	Employee Management
	Skills Management
	Project Management
    """,
    'data': ['hrms_view.xml'],
    'installable': True,
    'auto-install' : False,
}
