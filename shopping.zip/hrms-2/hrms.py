from osv import osv, fields
from datetime import datetime
from datetime import date

class hrms_employee(osv.Model):    # Employee Model class

	def _check_joindate(self, cr, userid, ids, context=None):
		for obj in self.browse(cr,userid,ids,context=context):
			inputdate = obj.joindate
			todaydt = datetime.today();
			
			joindt = datetime.strptime(inputdate,'%Y-%m-%d')
			if joindt > todaydt: 
				return False
		return True
		
	_name = 'hrms.employee'
	_description = "Employee class"
	_rec_name = 'empno'
	_columns ={
		'empno' : fields.integer('Empno', required=True),
		'empname' : fields.char('Empname', size=30, required=True),
		'job' : fields.char('Designation', size=20, required=True),
		'salary' : fields.float('Salary', digits=(7,2),required=True),
		'joindate' : fields.date('Hiredate'),
		'deptno_id' : fields.many2one('hrms.department','Deptno',required=True),
		'skill_ids' : fields.many2many('hrms.skills','rel_employee_skills', 'empno', 'skillid', 'Skills'),
		'photo' : fields.binary('Image')
	}
	_sql_constraints = [('hrms_employee_empno_uk','unique(empno)','Empno cannot be duplicated')]    #List of triples
	_constraints = [(_check_joindate, 'Hiredate cannot be future date', ['joindate'])]   #List of triples

	_defaults = {    	# dictionary
		'joindate' : date.today().strftime('%Y-%m-%d'),
		'deptno_id' : 10
	}  

class hrms_department(osv.Model):
	_name = 'hrms.department'
	_rec_name = 'deptno'
	_columns = {
		'deptno' : fields.integer('Deptno', required=True),
		'deptname' : fields.char('Deptname',size=20, required=True)
	}
	_sql_constraints = [('hrms_department_deptno_uk','unique(deptno)','Deptno cannot be duplicated')]
	
class hrms_skills(osv.Model):
	_name = 'hrms.skills'
	_description = 'Employee Skills'
	_rec_name = 'skillid'
	_columns = {
		'skillid' : fields.char('SkillId',size=15,required=True),
		'skilldesc' : fields.char('SkillDescription', size=30,required=True)
	}
	_sql_constraints = [('hrms_department_skillid_uk','unique(skillid)','Skilld cannot be duplicated')]














