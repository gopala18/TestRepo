{
    'name': 'Leave Management',
    'author': 'Ansh Kumar',
    'version': '1.0',
    'depends': ['base'],
    'category' : 'Tools',
    'summary': 'Leave Management Application',
    'description': """
		Leave Management Application
    """,
    'data': ['leave_view.xml'],
	'css' : ['static/src/css/style.css'],
	'qweb':['static/src/xml/custom.xml'],
    'installable': True,
    'auto-install' : True,
}
