from openerp import models, fields,api
from datetime import datetime

class leave_employees(models.Model):

	_name = 'leave.employees'
	_description = "Employees"
	#_inherit ='hrms.employee'
	_inherits = {'hrms.employee' : 'emp_id'}
	
	emp_id = fields.Many2one('hrms.employee',string="Employee Id", required=True)
	joindate = fields.Date(string='JoinDate')
	
	
	
class leave_leave_type(models.Model):
	_name = 'leave.leave.type'
	_description = "Leave Types"
	
	name = fields.Char(string='Leave Type Code',size=2,required=True)
	leavedescription= fields.Char(string='Leave Description', size=30, required=True)
	

class leave_employee_leave(models.Model):
	_name = 'leave.employee.leave'
	_description = 'Employee Leaves'
	
	empno =  fields.Many2one('leave.employees',string='Empno',required=True)
	leave_type_code = fields.Many2one('leave.leave.type', string='Leave Type Code', required=True)
	no_of_days = fields.Integer(string='No Of Days', required=True)
	leave_taken = fields.Integer(string='Leave Taken',readonly=True)
	leave_balance = fields.Integer(string='Leave Balance',readonly=True)
	

class leave_application(models.Model):

	@api.depends('startdate','enddate')
	def _get_days(self):
		sd = datetime.strptime(self.startdate,'%Y-%m-%d')
		ed = datetime.strptime(self.enddate,'%Y-%m-%d')
		timedelta = ed - sd
		result[obj.id] = timedelta.days + 1
		return result 

	@api.onchange('startdate','enddate')	
	def _onchange_date(self):
		sd = datetime.strptime(self.startdate,'%Y-%m-%d')
		ed = datetime.strptime(self.enddate,'%Y-%m-%d')
		timedelta = ed - sd
		self.no_of_days = timedelta.days + 1

	def create(self, cr, uid, vals, context=None):
		#cr.execute("update leave_employee_leave set leave_taken=leave_taken+1, leave_balance = leave_balance - ")	
		vals['state'] = 'applied'
		return super(leave_application,self).create(cr, uid, vals, context=context)
	
	def applyleave(self, cr, uid, ids, context=None):
		#Also perform additional code here if required.
		return self.write(cr, uid, ids, {'state': 'applied'},context=context)

	def approve(self, cr, uid, ids, context=None):
		#Also perform additional code here if required.
		return self.write(cr, uid, ids, {'state': 'approved'},context=context)
		
	def reject(self, cr, uid, ids, context=None):
		#Also perform additional code here if required.
		return self.write(cr, uid, ids, {'state': 'rejected'},context=context)

	_name = 'leave.application'
	_description = 'Leave Application'
	
	empno = fields.Many2one('leave.employees', string='Employee No', required=True,readonly=True, states={'new' : [('readonly', False)]})  
	startdate = fields.Date(string='Start date', required=True,readonly=True, states={'new' : [('readonly', False)]})  
	enddate = fields.Date(string='End Date', required=True,readonly=True, states={'new' : [('readonly', False)]})
	no_of_days = fields.Integer(compute='_get_days', string='No of Days')
	leave_type = fields.Many2one('leave.leave.type', string='Leave Type', required=True,readonly=True, states={'new' : [('readonly', False)]})
	reason = fields.Text(string='Reason ',readonly=True, states={'new' : [('readonly', False)]})
	state = fields.Selection([('new','Draft'),('applied','Applied'),('approved','Approved'),('rejected','Rejected')], 'Status', readonly=True, select=True)

	_defaults = {
		'state': 'new',
	}
	