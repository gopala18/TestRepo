{
    'name': 'HRMS',
    'author': 'RAM',
    'version': '0.2',
    'depends': ['base'],
    'category' : 'Tools',
    'summary': 'Human Resource Management System',
    'description': """ 
		Human Resource Management System   """,
    'data': ['hrms_view.xml'],
    'installable': True,
    'application' : True,
    
}
