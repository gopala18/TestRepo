from openerp import models,fields
class hrms_employee(models.Model):
	_name = "hrms.employee"
	_description ="Employee details"
	_rec_name = 'empno'
	
	empno = fields.Integer(string="Emp No",required=True)
	empname = fields.Char(string="Employee Name",required=True)
	deptno = fields.Many2one('hrms.department',string="Department No",required=True)
	job = fields.Char(string="Designation",required=True)
	skill_ids = fields.Many2many('hrms.skills',string="Skill name",required=True)
	salary = fields.Float(string="Salary",digits=(8,2),required=True)
	
class hrms_department(models.Model):
	_name = "hrms.department"
	_description ="Department details"
	_rec_name = "deptno"
	deptno = fields.Integer(string="Department No",required=True)
	deptname = fields.Char(string="Department Name",required=True)
	
	
class hrms_skills(models.Model):
	_name = "hrms.skills"
	_description ="Skills details"
	
	name = fields.Char(string="Skill name",required=True)
	skill_description = fields.Char(string="skill description",required=True)
	