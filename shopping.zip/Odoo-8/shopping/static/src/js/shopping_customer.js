openerp.shopping = function (instance) {

	instance.web.client_actions.add('customer.order.action', 'instance.shopping.Action');
	$('#webspan').hide();
		//Render options 
		var QWeb = instance.web.qweb;
		instance.shopping.Action = instance.web.Widget.extend({
			start: function() {
				var self = this;
				var customer = new instance.web.Model('shopping.customer');
				customer.query(['name','id'])
					.all().then(function (customers) {
						var $customers = $(QWeb.render("CustomerOrderTemplate", {customers: customers}));
						self.$el.append($customers);
						});
			},
			events : {
				'change #oe_shopping_select':'selectcustomerorders',
				'click #export_to_excel':'exporttoexcel',
				
			},
			selectcustomerorders : function(){
				var self = this;
				console.log($('#oe_shopping_select').val());
				var customerorders=new instance.web.Model('shopping.order')
				customerorders.query(['customername','orderdate','ordervalue','order_item_ids'])
				.filter([['customername', '=', parseInt($('#oe_shopping_select').val())]])
				.all().then(function (orders) {
							var $orders = $(QWeb.render("OrderTemplate", {orders: orders}));
							self.$el.append($orders);
							console.log(orders);
							});
						
			},
			exporttoexcel: function(){
				var  customername = {'customername' : $('#oe_shopping_select').val()};
				if (customername == "") {
					alert('Please select a customer');
				}
				else{
					var customerorders=new instance.web.Model('shopping.order').call("getcustomerorders",[customername],{context: new instance.web.CompoundContext()}).then(function(orders){
					});				
				}
			},
	});
 };