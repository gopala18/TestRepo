{
    'name': 'Shopping',
    'author': 'Ansh Kumar',
    'version': '1.0',
    'depends': ['base','web'],
    'category' : 'Tools',
    'summary': 'Shopping Cart Application',
    'description': """
		Shopping Cart Application
    """,
	'qweb':['static/src/xml/shopping_customer_order.xml'],	
    'data': ['shopping_view.xml',
			'shopping_report.xml','report/shopping_order_statistics_view.xml',
			'views/shopping_order_template.xml'],
		
    'installable': True,
    'auto-install' : True,
	
}
