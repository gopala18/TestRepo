from openerp import models, fields
from datetime import date
from openerp import api
from openerp.exceptions import Warning
import xlwt
import logging


class date_Val_Exceptions(Exception):
	def __init__(self,errorMsg="order date must not be future date"):
		self.errorMsg=errorMsg
	def __str__(self):
		return self.errorMsg
class shopping_product(models.Model):
	_name = "shopping.product"
	_description = "Product"

	name = fields.Char(string='Product Name',required=True)
	productdescription = fields.Text(string='Product Description')
	unitprice= fields.Float('Unit Price', digits=(7,2), required=True)
	quantity_on_hand = fields.Integer(string='Quantity On Hand', required=True)
	category_id =fields.Many2one('shopping.category', string='Category Name', required=True)
	supplier_ids = fields.Many2many('shopping.supplier',string='Supplier Name', required=True)
	productimage = fields.Binary(string='Product Image')
	
	_sql_constraints=[('prod_uniq_name','UNIQUE(name)',"product name already exists"),
					  ('check_qty_on_hand','CHECK(quantity_on_hand > 0)',"quantity shouldbe geater than zero")
					  ]
	
class shopping_category(models.Model):
	_name = "shopping.category"
	_description = "Product Category"
	name = fields.Char(string='Category Name',size=20, required=True)
	categorydescription= fields.Text(string='Category Descriptin')
	

class shopping_supplier(models.Model):
	_name = 'shopping.supplier'
	_description = "Product Supplier"

	name = fields.Char(string='Supplier Name',size=20, required=True)
	supplieraddress=fields.Text(string='Supplier Address')
	contactno = fields.Char(string='Contact No', size=15, required=True)
	contactperson=fields.Char(string='Contact Person',size=30, required=True)
	
	
class shopping_customer(models.Model):
	_name = 'shopping.customer'
	_description = 'Customers'
	name = fields.Char(string='Customer Name', size=20, required=True)
	shippingaddress= fields.Text(string='Shipping Addres')
	billingaddress= fields.Text(string='Billing Address')
	contactno =fields.Char(string='Contact No', size=15, required=True)
	contactperson=fields.Char(string='Contact Person', size=30, required=True)
	

class shopping_order(models.Model):
	_name = 'shopping.order'
	_description = 'Shopping Order'
	
	def getcustomerorders(self, cr, userid, param,context=None):
		logging.info("$$$$$$$$$$$$----" +  str(param));
		workbook = xlwt.Workbook()
		sheet1 = workbook.add_sheet('customerorders')
		cols = ["Sl.No", "Order Date", "Ordered Items", "Order Value"]
		
		cr.execute("""select o.orderdate, p.name , o.ordervalue
						from shopping_order o 
							inner join shopping_order_item item 
						on o.id = item.orderid 
						inner join shopping_product p
						on item.product_id = p.id 
						where o.customername = %d""" % (int(param['customername'])) )
		records = cr.fetchall()
		#sheet1.write(0,2, "Order Details")
		
		sheet1.col(0).width = 256 * 5
		sheet1.col(1).width = 256 * 5
		sheet1.col(2).width = 256 * 30
		sheet1.col(3).width = 256 * 10
		
		cell = 0
		row = 1
		for col in cols:
			sheet1.write(row, cell, col)
			cell += 1
		
		for record in records:
			row += 1
			sheet1.write(row, 0, row);
			for cell in range(1,4):
				sheet1.write(row,cell,record[cell-1])
		workbook.save("d:/customerorder.xls");
		return "Success"
		
	def print_shopping_order(self, cr, userid, ids, context=None):
		return {
			'type' : 'ir.actions.report.xml',
			'report_name' : 'shopping.order',
			'datas' : {
				'model' : 'shopping.order',
				'ids' :ids
			}
		}
		
	@api.onchange('order_item_ids')
	def _onchange_order_item_ids(self):
		order_items = self.env['shopping.order.item'].browse(self.order_item_ids)
		total=0.0
		for order_item in order_items:
			total = total + order_item.id.linetotal
		self.ordervalue =total
	
	@api.constrains('orderdate')
	def _check_orderdate(self):
		if self.orderdate >date.today().strftime('%Y-%m-%d'):
			raise Warning("order date should not be future date")
	
	def process_order(self, cr, userid, ids, context=None):
		""" Update the order state when user clicks on (Tick) Symbol """
		for order_ref in self.browse(cr, userid, ids, context=context):
			order_ref.write({'state':'confirm'})
		return True

	def cancel_order(self, cr, userid, ids, context=None):
		""" Cancel the order """
		self.unlink(cr, userid, ids, context=context)
		return True
		
	
	orderdate= fields.Date(string='Order Date', required=True,readonly=True,states = {'new':[('readonly' , False)]})
	customername= fields.Many2one('shopping.customer',string='Customer Name',required=True,readonly=True, states = {'new':[('readonly' , False)]})
	state=fields.Selection([('new','New'),('confirm','Confirmed'),('cancelled','Cancelled')])
	order_item_ids=fields.One2many('shopping.order.item','orderid',string='Order Items',ondelete='cascade', states = {'new':[('readonly' , False)]},readonly=True)
	ordervalue = fields.Float(string='Grand Total', digits=(7,2), required=True,readonly=True,states = {'new':[('readonly' , False)]})
	
	_defaults = {
		'orderdate' : date.today().strftime('%Y-%m-%d'),
		'state' : 'new'
	}	

class shopping_order_item(models.Model):

	@api.onchange('product_id','qty_ordered')
	def _onchange_productid(self):
		obj=self.env['shopping.product'].browse(self.product_id.id)
		self.unitprice=obj.unitprice
		self.linetotal=self.unitprice*self.qty_ordered
	
	_name = 'shopping.order.item'
	_description = 'Ordered Item'
	_rec_name = 'product_id'
	
	
	
	product_id= fields.Many2one('shopping.product', string='ProductName',required=True)
	orderid= fields.Many2one('shopping.order', string='OrderId', required=True, ondelete='cascade')
	qty_ordered=fields.Integer(string='Quantity',required=True)
	unitprice=fields.Float(string='Unit Price',required=True)
	linetotal=fields.Float(string='Line Total', digits=(7,2), required=True)
	#'suppliername':  fields.related('productname','supplier_ids',type='many2many',relation='shopping.supplier', string='Supplier')
	
	_defaults = {
		'qty_ordered' : 1
	}
