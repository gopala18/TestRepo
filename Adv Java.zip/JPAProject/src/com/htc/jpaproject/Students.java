package com.htc.jpaproject;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;

@Entity
@NamedQuery(name="selectByRegNo", query="select s from Students s where s.regNo=:reg")
public class Students {
	
	@Id
	@Column
	private int regNo;
	@Column
	private String name;
	@Column
	private String department;
	@Override
	public String toString() {
		return "Students [regNo=" + regNo + ", name=" + name + ", Department=" + department + "]";
	}
	public Students(int regNo, String name, String department) {
		super();
		this.regNo = regNo;
		this.name = name;
		this.department = department;
	}
	public Students() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getRegNo() {
		return regNo;
	}
	public void setRegNo(int regNo) {
		this.regNo = regNo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDepartment() {
		return department;
	}
	public void setDeparment(String department) {
		this.department = department;
	}
	
	

}
