package com.htc.hibernate_5.simple;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;

public class Main {
	static SessionFactory sessionFactory=null;
	static{
		Configuration config=new Configuration();
		StandardServiceRegistryBuilder builder=new StandardServiceRegistryBuilder();
		config.configure();
		builder.applySettings(config.getProperties());
		MetadataSources metadataSources=new MetadataSources();
		metadataSources.addAnnotatedClass(Computer.class);
		Metadata metadata=metadataSources.buildMetadata(builder.build());
		sessionFactory=metadata.buildSessionFactory();
	}
	public static void main(String[] args) {
	
		Computer computer=new Computer(124,"Samsung",12000.00);
		Session session=sessionFactory.openSession();
		Transaction trans=session.getTransaction();
		try{
			trans.begin();
			session.save(computer);
			trans.commit();
			System.out.println("Done");
			session.close();
		}catch(Exception ex){
			ex.printStackTrace();
			trans.rollback();
		}
		
	}

}
