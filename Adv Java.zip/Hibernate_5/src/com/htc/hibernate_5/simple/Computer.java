package com.htc.hibernate_5.simple;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;


@Entity(name="Computers")
public class Computer implements Serializable{

	@Id
	private int serialNo;
	@Column
	private String brand;
	@Column
	private double cost;
	@Override
	public String toString() {
		return "Computer [serialNo=" + serialNo + ", brand=" + brand + ", cost=" + cost + "]";
	}
	public Computer() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Computer(int serialNo, String brand, double cost) {
		super();
		this.serialNo = serialNo;
		this.brand = brand;
		this.cost = cost;
	}
	public int getSerialNo() {
		return serialNo;
	}
	public void setSerialNo(int serialNo) {
		this.serialNo = serialNo;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public double getCost() {
		return cost;
	}
	public void setCost(double cost) {
		this.cost = cost;
	}
	
	
}
