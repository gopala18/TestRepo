package com.htc.inheritancerelations;
// Testing Is-A and Has-A Relationship
public class Main {

	public static void main(String[] args) {

		Manager m=new Manager(111,"gopi",20000.00,"Java",5000.00);
		Manager m1=new Manager(112,"Raja",50000.00,"Java",4000.00);
		Department d=new Department();
		d.emp[0]=new Employee(123,"Gopi",12000.00);
		d.emp[1]=new Employee(124,"Siva",22000.00);
		d.emp[2]=new Employee(125,"Anish",52000.00);
		
		Department d1=new Department(202,"Training",d.emp);
		
		System.out.println(d1.toString());
		System.out.println(m.toString());
		System.out.println(m1.toString());
		
	}

}
