package com.htc.inheritancerelations;
// IS-A Relationship (Inheritance)
// Manager IS-A Employee
public class Manager extends Employee {
	
	private String currentProject;
	private double incentives;
	public String getCurrentProject() {
		return currentProject;
	}
	public void setCurrentProject(String currentProject) {
		this.currentProject = currentProject;
	}
	public double getIncentives() {
		return incentives;
	}
	public void setIncentives(double incentives) {
		this.incentives = incentives;
	}
	public Manager(int empId, String empName, double salary,
			String currentProject, double incentives) {
		super(empId, empName, salary);
		this.currentProject = currentProject;
		this.incentives = incentives;
	}
	public Manager() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Manager(int empId, String empName, double salary) {
		super(empId, empName, salary);
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return super.toString() + "Manager [currentProject=" + currentProject + ", incentives="
				+ incentives + "]";
	}
	
	

}
