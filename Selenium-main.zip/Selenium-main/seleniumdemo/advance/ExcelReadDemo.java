package com.seleniumdemo.advance;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Iterator;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelReadDemo {

	public static void main(String[] args) {
		String fileName = "data/TestData.xls";
		Workbook workbook = null;
		if (fileName.endsWith("xls")) {
			try {
				workbook = new HSSFWorkbook(new FileInputStream(new File(fileName)));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else if (fileName.endsWith("xlsx")) {
			try {
				workbook = new XSSFWorkbook(new FileInputStream(new File(fileName)));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else {
			try {
				throw new FileNotFoundException("File Format should be xls or xlsx...");
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
		}
		Sheet sheet = workbook.getSheet("LoginData");

		System.out.println("Rows:" + sheet.getPhysicalNumberOfRows());
		System.out.println("Cols:" + sheet.getRow(0).getLastCellNum());
		Iterator<Row> rows = sheet.rowIterator();
		while (rows.hasNext()) { // row
			Row row = rows.next();
			Iterator<Cell> cells = row.cellIterator();
			while (cells.hasNext()) { // cols
				Cell cell = cells.next();
				System.out.print(cell.getStringCellValue() + "\t");
			}
			System.out.println();
		}
	}

}
