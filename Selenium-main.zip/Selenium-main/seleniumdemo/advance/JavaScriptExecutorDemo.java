package com.seleniumdemo.advance;

import java.time.Duration;
import java.time.temporal.ChronoUnit;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

import com.seleniumdemo.util.WebDriversFactory;

public class JavaScriptExecutorDemo {

	public static void main(String[] args) {
		WebDriver driver=WebDriversFactory.getDriver("firefox");
		JavascriptExecutor js=(JavascriptExecutor)driver;
		driver.get("https://demoqa.com/automation-practice-form");
		driver.manage().timeouts().implicitlyWait(Duration.of(10, ChronoUnit.SECONDS));
		System.out.println(js.executeScript("return document.domain"));
		System.out.println(js.executeScript("return document.title"));
		js.executeScript("document.getElementById('firstName').style.visibility='hidden'");
		driver.manage().timeouts().implicitlyWait(Duration.of(10, ChronoUnit.SECONDS));
		
	}

}
