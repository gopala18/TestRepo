package com.seleniumdemo.advance;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.Duration;
import java.time.temporal.ChronoUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.seleniumdemo.util.WebDriversFactory;

public class ScreenshotDemo {

	public static void main(String[] args) {
		WebDriver driver=WebDriversFactory.getDriver("firefox");
		driver.get("https://google.com/");
		driver.manage().timeouts().implicitlyWait(Duration.of(10, ChronoUnit.SECONDS));
		ScreenshotDemo shot=new ScreenshotDemo();
		shot.takeScreenShot(driver,driver.getTitle()+".png");
		driver.navigate().to("https://google.com/gmail");
		shot.takeScreenShot(driver,"gmail.png");
		System.out.println(driver.getTitle());
		driver.quit();
		
	}
	public void takeScreenShot(WebDriver driver,String fileName) {
		TakesScreenshot shot=(TakesScreenshot)driver;
		File source=shot.getScreenshotAs(OutputType.FILE);
		try {
			File output=new File("screens/"+fileName);
			FileOutputStream des=new FileOutputStream(output);
			FileUtils.copyFile(source, des);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
