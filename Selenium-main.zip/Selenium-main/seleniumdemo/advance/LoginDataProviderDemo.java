package com.seleniumdemo.advance;

import java.time.Duration;
import java.time.temporal.ChronoUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.seleniumdemo.util.WebDriversFactory;

public class LoginDataProviderDemo {
	WebDriver driver;
	@BeforeTest
	public void config() {
		driver=WebDriversFactory.getDriver("firefox");
	}
	
	@Test(dataProvider="dataProviders")
	public void loginTest(String userName, String password) {
		driver.navigate().to("https://demoqa.com/login");
		driver.manage().timeouts().implicitlyWait(Duration.of(20, ChronoUnit.SECONDS));
		driver.findElement(By.id("userName")).sendKeys(userName);
		driver.findElement(By.id("password")).sendKeys(password);
		driver.findElement(By.id("login")).click();
		driver.manage().timeouts().implicitlyWait(Duration.of(20, ChronoUnit.SECONDS));
		//driver.findElement(By.linkText("Log Out")).click();				
	}
	@DataProvider
	public Object[][] dataProviders(){
		Object[][] data=ExcelReader.read();
		return data;
	}
	/*@Test
	public void tearDown() {
		driver.quit();
	}*/
}
