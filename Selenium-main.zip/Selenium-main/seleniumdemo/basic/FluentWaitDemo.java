package com.seleniumdemo.basic;

import java.time.Duration;
import java.time.temporal.ChronoUnit;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;

import com.seleniumdemo.util.WebDriversFactory;

public class FluentWaitDemo {

	public static void main(String[] args) {
		WebDriver driver=WebDriversFactory.getDriver("firefox");
		driver.get("https://google.com/");
		FluentWait wait=new FluentWait(driver);
		wait.withTimeout(Duration.of(10, ChronoUnit.SECONDS));
		wait.pollingEvery(Duration.of(3, ChronoUnit.SECONDS));
		wait.ignoring(NoSuchElementException.class);
		
		wait.until(ExpectedConditions.titleContains("Google"));
		System.out.println(driver.getTitle());
		driver.manage().timeouts().implicitlyWait(Duration.of(1, ChronoUnit.MINUTES));
		System.out.println("Wait is over...");
		driver.quit();
		
		
	}

}
