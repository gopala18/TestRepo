package com.seleniumdemo.basic;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.seleniumdemo.util.WebDriversFactory;

public class VerificationCommands {

	public static void main(String[] args) throws InterruptedException {
	WebDriver driver=WebDriversFactory.getDriver("firefox");
	driver.get("https://seleniumbase.io/demo_page");
	Thread.sleep(3000);
	//Validation
	System.out.println(driver.findElement(By.id("checkBox5")).isSelected());
	System.out.println(driver.findElement(By.id("checkBox4")).isSelected());
	
	System.out.println(driver.findElement(By.id("myLink1")).isEnabled());
	System.out.println(driver.findElement(By.id("myLink1")).isDisplayed());
	
	System.out.println(driver.getTitle());
	//Assert.assertEquals(driver.getTitle(),"Web Testing Page");
	
	for(String data:driver.getWindowHandles()) {
		System.out.println(data);
	}
	
	
	}

}
