package com.seleniumdemo.basic;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeDriverService;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

public class BrowserOptions {

	public static void main(String[] args) {
		System.setProperty(ChromeDriverService.CHROME_DRIVER_EXE_PROPERTY,"drivers/chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.addArguments("start-maximized");
		options.addArguments("incognito");
		options.addArguments("disable-infobars");
		
		// Create an object of desired capabilities class with Chrome driver
		DesiredCapabilities SSLCertificate = new DesiredCapabilities();
		// Set the pre defined capability � ACCEPT_SSL_CERTS value to true
		SSLCertificate.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
		// Open a new instance of chrome driver with the desired capability
		options.merge(SSLCertificate);
		
		WebDriver driver=new ChromeDriver(options);
		driver.get("https://google.com");
		driver.quit();
	}

}
