package com.seleniumdemo.basic;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;

import com.seleniumdemo.util.WebDriversFactory;

public class KeyboardActionDemo {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver=WebDriversFactory.getDriver("firefox");
		driver.get("https://the-internet.herokuapp.com/key_presses");
		Thread.sleep(3000);
		Actions action=new Actions(driver);
		driver.findElement(By.id("target")).sendKeys("This is a demo for Keyboard actions");
		action.sendKeys(Keys.BACK_SPACE).sendKeys(Keys.BACK_SPACE).build().perform();;
		Thread.sleep(3000);
				
		action.sendKeys(Keys.TAB).sendKeys(Keys.ENTER).build().perform();
		
	}

}
