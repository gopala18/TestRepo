package com.seleniumdemo.basic;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WindowType;

import com.seleniumdemo.util.WebDriversFactory;

public class WindowHandleDemo {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = WebDriversFactory.getDriver("firefox");
		driver.get("https://demoqa.com/browser-windows");
		String mainWindow = driver.getWindowHandle();
		System.out.println("Main:" + mainWindow);
		//driver.findElement(By.id("tabButton")).click();
		//driver.findElement(By.id("windowButton")).click();
		/*driver.findElement(By.id("messageWindowButton")).click();
		Set<String> handles = driver.getWindowHandles();
		for (String child : handles) {
			if (!child.equals(mainWindow)) {
				driver.switchTo().window(child);
			}
		}
		System.out.println(driver.getPageSource());
		System.out.println(driver.findElement(By.tagName("body")).getText());
		//driver.switchTo().defaultContent();
*/		driver.switchTo().newWindow(WindowType.WINDOW);
		driver.navigate().to("https://selenium.dev/");
		Thread.sleep(3000);
		System.out.println(driver.getTitle());
		driver.switchTo().window(mainWindow);
		Thread.sleep(3000);
		driver.quit();
	}

}
