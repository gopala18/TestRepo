package com.seleniumdemo.basic;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.seleniumdemo.util.WebDriversFactory;

public class AlertDemo {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver=WebDriversFactory.getDriver("firefox");
		driver.get("https://demoqa.com/alerts");
		Thread.sleep(3000);
		//driver.findElement(By.id("alertButton")).click();
		//driver.findElement(By.id("confirmButton")).click();
		driver.findElement(By.id("promtButton")).click();
		
		Alert alert=driver.switchTo().alert();
		System.out.println("Alert Message: "+alert.getText());
		//alert.accept();
		alert.sendKeys("This is a demo alert");
		Thread.sleep(3000);
		alert.accept();
		driver.close();
	}

}
