package com.seleniumdemo.basic;

import java.time.Duration;
import java.time.temporal.ChronoUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.seleniumdemo.util.WebDriversFactory;

public class ExplicitWaitDemo {

	public static void main(String[] args) {
		WebDriver driver=WebDriversFactory.getDriver("firefox");
		driver.get("https://google.com/");
		//driver.manage().timeouts().implicitlyWait(Duration.of(5, ChronoUnit.SECONDS));
		WebDriverWait wait=new WebDriverWait(driver,Duration.of(5, ChronoUnit.SECONDS));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("q")));
		driver.findElement(By.name("q")).sendKeys("selenium wait");
		driver.findElement(By.name("q")).sendKeys(Keys.ENTER);
		System.out.println(driver.getTitle());
		driver.quit();
	}

}
