package com.seleniumdemo.basic;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;

import com.seleniumdemo.util.WebDriversFactory;

public class MouseMoveDemo {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver=WebDriversFactory.getDriver("firefox");
		driver.get("https://seleniumbase.io/demo_page");
		Thread.sleep(3000);
		Actions action=new Actions(driver);
		Action builtAction=action.moveToElement(driver.findElement(By.id("myDropdown"))).build();
		builtAction.perform();
		Thread.sleep(3000);
		action.moveToElement(driver.findElement(By.id("dropOption1"))).build().perform();
		Thread.sleep(2000);
		action.moveToElement(driver.findElement(By.id("dropOption2"))).build().perform();
		Thread.sleep(2000);
		action.moveToElement(driver.findElement(By.id("dropOption3"))).build().perform();
		driver.close();
		
	}

}
