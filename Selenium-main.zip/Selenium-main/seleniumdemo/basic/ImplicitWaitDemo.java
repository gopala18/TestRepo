package com.seleniumdemo.basic;

import java.time.Duration;
import java.time.temporal.ChronoUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

import com.seleniumdemo.util.WebDriversFactory;

public class ImplicitWaitDemo {

	public static void main(String[] args) {
		WebDriver driver=WebDriversFactory.getDriver("firefox");
		driver.get("https://google.com/");
		driver.manage().timeouts().implicitlyWait(Duration.of(5, ChronoUnit.SECONDS));
		driver.findElement(By.name("q")).sendKeys("selenium wait");
		driver.findElement(By.name("q")).sendKeys(Keys.ENTER);
		System.out.println(driver.getTitle());

		driver.manage().timeouts().implicitlyWait(Duration.of(10, ChronoUnit.SECONDS));
		//driver.quit();
	}

}
