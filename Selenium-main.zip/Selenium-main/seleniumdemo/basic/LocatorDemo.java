package com.seleniumdemo.basic;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeDriverService;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.seleniumdemo.util.WebDriversFactory;

public class LocatorDemo {
	WebDriver driver;

	@BeforeClass
	public void webDriverConfig() {
		driver=WebDriversFactory.getDriver("chrome");
	}

	@Test
	public void navigateTo() {
		driver.get("https://www.techlistic.com/p/selenium-practice-form.html");
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		Assert.assertEquals(driver.getCurrentUrl(), "https://www.techlistic.com/p/selenium-practice-form.html");
	}

	@Test(dependsOnMethods = { "navigateTo" })
	public void registrationForm() {

		// name locator
		WebElement firstnametxt = driver.findElement(By.name("firstname"));
		firstnametxt.sendKeys("Charles");
		driver.findElement(By.name("lastname")).sendKeys("Darwin");

		List<WebElement> genders = driver.findElements(By.name("sex"));
		// gender=Male
		for (WebElement element : genders) {
			if (element.getAttribute("value").equalsIgnoreCase("male")) {
				element.click();
				break;
			}
		}
		//id locator
		driver.findElement(By.id("datepicker")).sendKeys("26/05/2022");
		
		List<WebElement> professions=driver.findElements(By.name("profession"));
		// profession=Automation Tester
		for (WebElement element : professions) {
			if (element.getAttribute("value").equalsIgnoreCase("Automation Tester")) {
				element.click();
				break;
			}
		}
		
		Select continents=new Select(driver.findElement(By.id("continents")));
		continents.selectByVisibleText("Asia");
		
		
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//Link Text or Partial link text
		driver.findElement(By.linkText("Automate Amazon like E-Commerce website with Selenium")).click();
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		driver.navigate().back();
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//partial link
		driver.findElement(By.partialLinkText("Amazon")).click();
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@AfterClass
	public void webDriverClose() {
		driver.close();
	}

}
