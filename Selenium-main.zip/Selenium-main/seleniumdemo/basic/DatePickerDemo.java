package com.seleniumdemo.basic;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.seleniumdemo.util.WebDriversFactory;

public class DatePickerDemo {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver=WebDriversFactory.getDriver("firefox");
		/*driver.get("https://demo.guru99.com/test/");
		Thread.sleep(3000);
		driver.findElement(By.name("bdaytime")).sendKeys("05/30/2022");
		Thread.sleep(3000);*/
		driver.get("https://demoqa.com/date-picker");
		Thread.sleep(3000);
		driver.findElement(By.id("datePickerMonthYearInput")).click();
		Thread.sleep(3000);
		Select month=new Select(driver.findElement(By.xpath("//select[@class='react-datepicker__month-select']")));
		month.selectByVisibleText("January");
		Thread.sleep(3000);
		Select year=new Select(driver.findElement(By.xpath("//select[@class='react-datepicker__year-select']")));
		year.selectByVisibleText("2010");
		Thread.sleep(3000);
		List<WebElement> days=driver.findElements(By.xpath("//div[contains(@class,'react-datepicker__day')]"));
		
		for(WebElement day:days) {
			System.out.println(day.getText());
		}
		for(WebElement day:days) {
			if(day.getText().equals("7")) {
				day.click();
				break;
			}
		}
		Thread.sleep(3000);
		driver.close();
	}

}
