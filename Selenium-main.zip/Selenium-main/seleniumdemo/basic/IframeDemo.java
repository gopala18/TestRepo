package com.seleniumdemo.basic;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.seleniumdemo.util.WebDriversFactory;

public class IframeDemo {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = WebDriversFactory.getDriver("chrome");
		driver.get("https://the-internet.herokuapp.com/iframe");
		driver.switchTo().frame(0); //transfer the driver control to Iframe
		//driver.findElement(By.tagName("p")).clear();
		//driver.findElement(By.tagName("p")).sendKeys("This is an iframe");
		driver.findElement(By.xpath("//p")).clear();
		driver.findElement(By.xpath("//p")).sendKeys("This is an Iframe...");
		Thread.sleep(3000);
		driver.close();
		
	}

}
