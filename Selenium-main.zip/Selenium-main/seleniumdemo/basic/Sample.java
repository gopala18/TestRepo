package com.seleniumdemo.basic;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WindowType;
import org.openqa.selenium.chrome.ChromeDriver;

import com.seleniumdemo.util.WebDriversFactory;

public class Sample {

	public static void main(String[] args) throws InterruptedException {
		//System.setProperty("webdriver.chrome.driver", "drivers/chromedriver.exe");
		WebDriver driver=WebDriversFactory.getDriver("firefox");
		driver.get("https://google.com");
		driver.manage().window().maximize();
		//driver.navigate().to("https://google.com");
		Thread.sleep(3000);
		
		System.out.println(driver.getTitle());
		//System.out.println(driver.getPageSource()); // web Crawler
		driver.close();
	}

}
