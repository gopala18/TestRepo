package com.seleniumdemo.basic;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.seleniumdemo.util.WebDriversFactory;

public class NavigateCommand {

	public static void main(String[] args) {
		WebDriver driver=WebDriversFactory.getDriver("html");
		/*System.setProperty("webdriver.chrome.driver", "drivers/chromedriver.exe");
		WebDriver driver=new ChromeDriver();
*/
		driver.get("https://google.com");
		System.out.println(driver.getCurrentUrl());
		driver.navigate().to("https://google.com/gmail");
		System.out.println(driver.getCurrentUrl());
		driver.navigate().back();// back to google home page
		System.out.println(driver.getTitle());
		driver.navigate().forward(); // forward to google.com/gmail
		try {
			Thread.sleep(5000); // for learning purpose only
			// use WebDriverWait instead //implicitwait,fluentwait
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		driver.navigate().refresh();
		driver.close();
	}

}
