package com.seleniumdemo.util;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeDriverService;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.GeckoDriverService;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerDriverService;

public class WebDriversFactory {

	private static WebDriver driver;

	public static WebDriver getDriver(String browserName) {
		if (browserName.equalsIgnoreCase("chrome")) {
			System.out.println("chrome browser");
			System.setProperty(ChromeDriverService.CHROME_DRIVER_EXE_PROPERTY, "drivers/chromedriver.exe");
			driver = new ChromeDriver();
		} else if (browserName.equalsIgnoreCase("firefox")) {
			System.out.println("firefox browser");
			System.setProperty(GeckoDriverService.GECKO_DRIVER_EXE_PROPERTY, "drivers/geckodriver.exe");
			driver = new FirefoxDriver();
		} else if (browserName.equalsIgnoreCase("IE")) {
			System.out.println("IE browser");
			System.setProperty(InternetExplorerDriverService.IE_DRIVER_EXE_PROPERTY, "drivers/IEDriverServer.exe");
			driver = new InternetExplorerDriver();
		} else {
			driver = new HtmlUnitDriver(true);
			System.out.println("The requested browser is not available- using headless execution");
		}
		return driver;
	}
}
