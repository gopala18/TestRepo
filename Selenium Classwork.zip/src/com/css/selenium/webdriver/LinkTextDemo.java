package com.css.selenium.webdriver;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.css.selenium.utils.WebDriversFactory;

public class LinkTextDemo {

	public static void main(String[] args) throws InterruptedException {
		String baseUrl = "https://www.selenium.dev/downloads/";

		WebDriver driver = WebDriversFactory.getDriver("chrome");

		driver.get(baseUrl);
		Thread.sleep(3000);
		//driver.findElement(By.linkText("Previous Releases")).click();
		//driver.navigate().back();
				
		List<WebElement> links=driver.findElements(By.tagName("a"));
		for(WebElement element:links) {
			System.out.println(element.getText());
		}
		driver.findElement(By.partialLinkText("doc")).click();
		System.out.println("title of page is: " + driver.getTitle());
		driver.quit();
	}

}
