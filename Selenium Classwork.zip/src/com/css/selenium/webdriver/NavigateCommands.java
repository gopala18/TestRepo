package com.css.selenium.webdriver;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import com.css.selenium.utils.WebDriversFactory;

public class NavigateCommands {
	public static void main(String[] args) {
		// Create a new instance of the Chrome driver
		WebDriver driver = WebDriversFactory.getDriver("chrome");

		// Open ToolsQA web site
		String appUrl = "https://www.toolsqa.com/";
		driver.get(appUrl);

		// Click on Blog link
		driver.findElement(By.xpath("//*[@id=\"primary-menu\"]/li[5]/a/span/span")).click();

		// Go back to Home Page
		driver.navigate().back();

		// Go forward to Blog page
		driver.navigate().forward();

		// Go back to Home page
		driver.navigate().to(appUrl);

		// Refresh browser
		driver.navigate().refresh();

		// Close browser
		driver.close();
	}
}