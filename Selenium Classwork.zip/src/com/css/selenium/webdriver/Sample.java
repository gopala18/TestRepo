package com.css.selenium.webdriver;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.css.selenium.utils.WebDriversFactory;

public class Sample {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver=WebDriversFactory.getDriver("chrome");
		driver.get("https://google.com");
		System.out.println(driver.getTitle());
		WebElement searchElement=driver.findElement(By.name("q"));
		searchElement.sendKeys("Testing");
		//Only for testing Do not use in testing script.
		Thread.sleep(2000);
		
		driver.close();
	}
}
