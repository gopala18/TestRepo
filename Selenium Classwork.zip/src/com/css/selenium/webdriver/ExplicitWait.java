package com.css.selenium.webdriver;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import com.css.selenium.utils.WebDriversFactory;

public class ExplicitWait {

	protected WebDriver driver;

	@Test
	public void guru99tutorials() throws InterruptedException {

		driver = WebDriversFactory.getDriver("chrome");
		
		WebDriverWait wait=new WebDriverWait(driver, 20);
		// launch Chrome and redirect it to the Base URL
		driver.get("https://www.guru99.com/" );
		//Maximizes the browser window
		driver.manage().window().maximize() ;
		//get the actual value of the title
		
		WebElement guru99seleniumlink;
		
		guru99seleniumlink= wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath( "//*[@id=\"java_technologies\"]/li[3]/a")));
		guru99seleniumlink.click();
		driver.close();
	}
}