package com.css.selenium.webdriver;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;

import com.css.selenium.utils.WebDriversFactory;

public class ActionsDemo {

	public static void main(String[] args) throws InterruptedException {
		String baseUrl = "http://demo.guru99.com/test/newtours/";
        
                WebDriver driver = WebDriversFactory.getDriver("chrome");
                /*
                driver.get(baseUrl);           
                driver.manage().window().maximize();
                WebElement link_Home = driver.findElement(By.linkText("Home"));
                WebElement td_Home = driver
                        .findElement(By
                        .xpath("//html/body/div"
                        + "/table/tbody/tr/td"
                        + "/table/tbody/tr/td"
                        + "/table/tbody/tr/td"
                        + "/table/tbody/tr"));    
                 
                Actions builder = new Actions(driver);
                Action mouseOverHome = builder
                        .moveToElement(link_Home)
                        .build();
                 
                String bgColor = td_Home.getCssValue("background-color");
                System.out.println("Before hover: " + bgColor);        
                mouseOverHome.perform();        
                Thread.sleep(2000);
                bgColor = td_Home.getCssValue("background-color");
                System.out.println("After hover: " + bgColor);
                */
                //Series of action
                
                driver.get("http://demo.guru99.com/test/login.html");
                WebElement txtUsername = driver.findElement(By.id("email"));

                Actions builder = new Actions(driver);
                
                Action seriesOfActions = builder
                	.moveToElement(txtUsername)
                	.click()
                	.keyDown(txtUsername, Keys.SHIFT)
                	.sendKeys(txtUsername, "ActionClass2.")
                	.keyUp(txtUsername, Keys.SHIFT)
                	.doubleClick(txtUsername)
                	.contextClick()
                	.build();
                	
                seriesOfActions.perform() ;
                
                Thread.sleep(2000);
                driver.close();
	}

}
