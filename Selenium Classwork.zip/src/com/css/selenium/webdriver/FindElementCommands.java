package com.css.selenium.webdriver;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;

import com.css.selenium.utils.WebDriversFactory;

public class FindElementCommands {
	public static void main(String[] args) throws InterruptedException {

		WebDriver driver = WebDriversFactory.getDriver("chrome");

		// Launch the ToolsQA WebSite
		driver.get("https://demoqa.com/automation-practice-form");
		driver.manage().window().maximize();
		// Type Name in the FirstName text box
		driver.findElement(By.id("firstName")).sendKeys("Gopi");

		// Type LastName in the LastName text box
		driver.findElement(By.id("lastName")).sendKeys("Muruganantham");

		// driver.findElement(By.cssSelector("#gender-radio-1")).click();

		Actions act = new Actions(driver);
		act.moveToElement(driver.findElement(By.cssSelector("#gender-radio-1"))).click().perform();

		// Click on the Submit button
		Thread.sleep(5000);
		driver.close();
	}
}
