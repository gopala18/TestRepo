package com.css.selenium.webdriver;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.css.selenium.utils.WebDriversFactory;

public class WebElementCommands {

	public static void main(String[] args) {

		// Create a new instance of the Chrome driver
		WebDriver driver = WebDriversFactory.getDriver("chrome");

		// Storing the Application Url in the String variable
		String url = "https://demoqa.com/automation-practice-form";

		// Launch the demoQA WebSite
		driver.get(url);

		//SendKeys
		
		WebElement element = driver.findElement(By.id("firstName"));
		element.sendKeys("ToolsQA");

		//Or can be written as
		//driver.findElement(By.id("firstName")).sendKeys("ToolsQA");
		
		//Clear
		driver.findElement(By.id("firstName")).clear();
		
		//isDisplayed 
		boolean status = driver.findElement(By.id("firstName")).isDisplayed();
		System.out.println("is Displayed: "+status);

		//isEnabled
		boolean enableFlag = driver.findElement(By.id("firstName")).isEnabled();
		 
		// Check that if the Text field is enabled, if yes enter value
		if(enableFlag){
		    element.sendKeys("ToolsQA");
		}
		
		driver.findElement(By.xpath("//*[@id=\"genterWrapper\"]/div[2]/div[1]")).click();
		//isSelected
		boolean genderFlag = driver.findElement(By.id("gender-radio-1")).isSelected();
		System.out.println("is Selected: "+genderFlag);
		
		//getText
		
		String formLabel=driver.findElement(By.xpath("//*[@id=\"app\"]/div/div/div[2]/div[2]/div[1]/h5")).getText();
		System.out.println("Form Label: "+formLabel);
		
		// Closing browser
		driver.close();
	}

}