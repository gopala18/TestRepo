package com.css.selenium.webdriver;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;

import com.css.selenium.utils.WebDriversFactory;


public class GithubLogin {

	WebDriver driver=WebDriversFactory.getDriver("chrome");
	@Test(priority=0)
	public void navigateToGithub() {
		driver.navigate().to("https://github.com/");
		//driver.get("https://github.com/");
		Assert.assertEquals(driver.getTitle(),"GitHub: Where the world builds software � GitHub");
	}
	@Test(priority=1)
	public void clickOnLogin() {      
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		//WebElement signIn=driver.findElement(By.xpath("/html/body/div[1]/header/div/div[2]/div[2]/a[1]"));
		//signIn.click();
		driver.navigate().to("https://github.com/login");
		Assert.assertEquals(driver.getTitle(), "Sign in to GitHub � GitHub");
	}
	
	@Test(priority=2)
	public void enterLoginCredentials() {
		driver.findElement(By.id("login_field")).sendKeys("Training");
		driver.findElement(By.id("password")).sendKeys("password");
		driver.findElement(By.name("commit")).click();
	}
	@AfterClass
	public void resourceRelease() {
		driver.close();
	}
	

}
