package selenium;

public class HandlingFrames 
{
	//Any Frame in Selenium WebDriver can be handled by using
	//1. Id Or Name,
	//2. Index.
	//3. WebElement.
}
