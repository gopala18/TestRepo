package selenium;

public class ElementNotClickableException 
{
	//It can be handled in 3 ways:
	//1. Trying with Different XPath.
	//2. Using Mouse Hover and We can write Function for it.
	//3. Use Java Script Executor.
}
