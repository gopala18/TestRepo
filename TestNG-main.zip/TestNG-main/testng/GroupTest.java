package com.unittesting.testng;

import org.testng.annotations.Test;

@Test(groups= {"others"})
public class GroupTest {

	@Test(groups={"functional"})
	public void testCase1() {
		System.out.println("Test Case1");
	}
	@Test(groups={"functional"})
	public void testCase2() {
		System.out.println("Test Case2");
	}
	@Test(groups={"userAcceptance"})
	public void testCase3() {
		System.out.println("Test Case3");
	}
	@Test
	public void testCase4() {
		System.out.println("Test Case4");
	}
	@Test
	public void testCase5() {
		System.out.println("Test Case5");
	}
}
