package com.unittesting.testng;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class ParametersTest {

	@Parameters("param")
	@Test
	public void greetingTestCase(String name) {
		System.out.println("Hello "+name);
	}
	@Test
	@Parameters({"num1","num2"})
	public void additionTestCase(int num1,int num2) {
		System.out.println("Result: "+(num1+num2));
	}
}
