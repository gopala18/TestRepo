package com.unittesting.testng;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

@Listeners(TestListenerDemo.class)
public class AnnotationsTest {
	@Test
	public void testCase1() {
		System.out.println("Test case method1...");
	}

	@Test
	public void testCase2() {
		System.out.println("Test case method2...");
	}

	@Test
	public void testCase3() {
		System.out.println("Test case method3...");
	}

	@BeforeMethod
	public void beforeMethod() {
		System.out.println("method level config eg. parameters");
	}

	@AfterMethod
	public void afterMethod() {
		System.out.println("releasing method level config.");
	}

	@BeforeClass
	public void beforeClass() {
		System.out.println("config for report");
	}

	@AfterClass
	public void afterClass() {
		System.out.println("save your report");
	}

	@BeforeTest
	public void beforeTest() {
		System.out.println("Test Case level config...");
	}

	@AfterTest
	public void afterTest() {
		System.out.println("release test case level config...");
	}

	@BeforeSuite
	public void beforeSuite() {
		System.out.println("Suite level configurations");
	}

	@AfterSuite
	public void afterSuite() {
		System.out.println("release suite level config...");
	}

}
