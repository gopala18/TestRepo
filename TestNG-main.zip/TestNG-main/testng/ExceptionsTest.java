package com.unittesting.testng;

import org.testng.annotations.Test;

public class ExceptionsTest {
	// search employee in a department based on empID.
	@Test(expectedExceptions= {EmployeeNotFoundException.class},expectedExceptionsMessageRegExp="Employee Not Found...")
	public void getEmployee()throws EmployeeNotFoundException{
		throw new NullPointerException();	
	}
	
}
