package com.unittesting.testng;

import org.testng.IRetryAnalyzer;
import org.testng.ITestResult;

public class RetryTest implements IRetryAnalyzer{

	private int executionCounter=0;
	private int maxRetry=3;
	@Override
	public boolean retry(ITestResult result) {
		if(executionCounter<maxRetry) {
			executionCounter++;
			return true;
		}
		return false;
	}

}
