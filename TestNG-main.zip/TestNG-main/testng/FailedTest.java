package com.unittesting.testng;

import org.testng.Assert;
import org.testng.annotations.Test;


public class FailedTest {

	@Test(retryAnalyzer=RetryTest.class)
	public void testCase() {
		Assert.assertTrue(false);
	}
}
