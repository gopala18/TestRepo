package com.unittesting.testng;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class AssertionTest {

	@Test(dataProvider = "loginDataProvider")
	public void loginTest(String userName, String password) {
		// Valid username and password
		Assert.assertEquals(userName, "John");
		Assert.assertEquals(password, "12345");
		
		// example for real time scenario
		//Assert.assertTrue(loginValidation(userName,password));
	}

	@Test
	public void testCase1() {
		//Assert.assertTrue(1 > 2);
		Assert.fail("Manual Fail");
	}

	@DataProvider
	public Object[][] loginDataProvider() {
		Object[][] data = new Object[2][2];

		data[0][0] = "John";
		data[0][1] = "12345";

		data[1][0] = "Gopi";
		data[1][1] = "mypassword";

		return data;
	}
}
