package com.unittesting.testng;

public class EmployeeNotFoundException extends Exception {
	private String errorMessage = "Employee Not Found...";

	public EmployeeNotFoundException(String errorMessage) {
		super();
		this.errorMessage = errorMessage;
	}

	public EmployeeNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String getMessage() {
		return this.errorMessage;
	}

}
