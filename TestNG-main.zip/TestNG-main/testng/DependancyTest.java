package com.unittesting.testng;

import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
@Listeners(TestListenerDemo.class)
public class DependancyTest {

	@Test
	public void loginTestCase() {
		System.out.println("Login");
		throw new NullPointerException();
	}

	@Test(dependsOnMethods = { "sendMailTestCase" })
	public void logoutTestCase() {
		System.out.println("Logout...");
	}

	@Test(dependsOnMethods = { "loginTestCase" })
	public void sendMailTestCase() {
		System.out.println("sending a mail...");
	}
}
