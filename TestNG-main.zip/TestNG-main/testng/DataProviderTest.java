package com.unittesting.testng;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class DataProviderTest {

	@Test(dataProvider = "loginDataProvider")
	public void loginTest(String userName, String password) {
		if (userName.equals("John")) {
			if (password.equals("12345")) {
				System.out.println("Success");
			}
		} else {
			System.out.println("Failure");
		}
	}

	@DataProvider
	public Object[][] loginDataProvider() {
		Object[][] data = new Object[2][2];

		data[0][0] = "John";
		data[0][1] = "12345";

		data[1][0] = "Gopi";
		data[1][1] = "mypassword";

		return data;
	}
}
