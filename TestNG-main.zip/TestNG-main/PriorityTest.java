package com.unittesting.testng;

import org.testng.annotations.Test;

public class PriorityTest {
// if you're providing priority make sure you provide for all the test methods
	// lowest integer-->highest priority
	@Test(priority = 1975)
	public void testCase1() {
		System.out.println("Second Highest: Test case method1...");
	}

	@Test(priority = 276574)
	public void testCase2() {
		System.out.println("Test case method2...");
	}

	@Test(priority = 100)
	public void testCase3() {
		System.out.println("Highest Priority: Test case method3...");
	}

}
