package com.bankapplication.exceptions;

public class InvalidAccountNoException extends Exception {

	private String errMessage="Invalid Account number...";

	public InvalidAccountNoException(String errMessage) {
		super();
		this.errMessage = errMessage;
	}

	public InvalidAccountNoException() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String getMessage() {
		// TODO Auto-generated method stub
		return this.errMessage;
	}
	
}
