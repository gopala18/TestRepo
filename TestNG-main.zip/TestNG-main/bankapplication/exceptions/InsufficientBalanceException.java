package com.bankapplication.exceptions;

public class InsufficientBalanceException extends Exception {
	private String errMessage="Insufficient Balance in your account...";

	public InsufficientBalanceException(String errMessage) {
		super();
		this.errMessage = errMessage;
	}

	public InsufficientBalanceException() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String getMessage() {
		// TODO Auto-generated method stub
		return this.errMessage;
	}
	

}
