package com.bankapplication.entities;

import java.util.ArrayList;

import com.bankapplication.exceptions.InsufficientBalanceException;
import com.bankapplication.exceptions.InvalidAccountNoException;

public class Bank {
	private String IFSC;
	private String bankName;
	private ArrayList<BankAccount> accounts;
	
	public String getIFSC() {
		return IFSC;
	}
	public void setIFSC(String iFSC) {
		IFSC = iFSC;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public ArrayList<BankAccount> getAccounts() {
		return accounts;
	}
	public void setAccounts(ArrayList<BankAccount> accounts) {
		this.accounts = accounts;
	}
	public Bank(String iFSC, String bankName, ArrayList<BankAccount> accounts) {
		super();
		IFSC = iFSC;
		this.bankName = bankName;
		this.accounts = accounts;
	}
	public Bank() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Bank [IFSC=" + IFSC + ", bankName=" + bankName + ", accounts=" + accounts + "]";
	}
	
	public BankAccount checkAccount(int accountNo)throws InvalidAccountNoException {
		BankAccount foundAccount=null;
		for(BankAccount account: accounts) {
			if(account.getAccountNo()==accountNo) {
				foundAccount=account;
				break;
			}
		}
		if(foundAccount==null)
			throw new InvalidAccountNoException();
		
		return foundAccount;
	}
	public boolean deposit(int accountNo,double amount)throws InvalidAccountNoException {
		boolean depositFlag=false;
		BankAccount foundAccount=this.checkAccount(accountNo);
		if(foundAccount!=null) {
			foundAccount.setBalance(foundAccount.getBalance()+amount);
			depositFlag=true;
		}else {
			throw new InvalidAccountNoException();
		}
		return depositFlag;
		
	}
	public boolean withdraw(int accountNo, double amount)throws InvalidAccountNoException,InsufficientBalanceException{
		boolean withdrawFlag=false;
		BankAccount foundAccount=this.checkAccount(accountNo);
		if(foundAccount!=null) {
			double existingBalance=foundAccount.getBalance();
			if(existingBalance>=amount) {
				foundAccount.setBalance(existingBalance-amount);
				withdrawFlag=true;
			}else {
				throw new InsufficientBalanceException();
			}
			
		}
		
		return withdrawFlag;
	}
	public boolean transfer(int fromAccountNo, int toAccountNo,double amount)throws InvalidAccountNoException {
		boolean transferFlag=false;
		return transferFlag;
		
	}
}
