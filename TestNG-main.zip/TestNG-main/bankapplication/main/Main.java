package com.bankapplication.main;

import java.util.ArrayList;

import com.bankapplication.entities.Bank;
import com.bankapplication.entities.BankAccount;
import com.bankapplication.exceptions.InvalidAccountNoException;

public class Main {

	public static void main(String[] args) {
		ArrayList<BankAccount> accounts=new ArrayList<BankAccount>();
		accounts.add(new BankAccount(123,"Gopi",1000));
		accounts.add(new BankAccount(124,"Jai",5000));
		accounts.add(new BankAccount(125,"Raj",2400));
		
		Bank bank=new Bank("icici123","ICICI",accounts);
		
		try {
			System.out.println(bank.deposit(123, 2345));
		} catch (InvalidAccountNoException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			System.out.println(bank.checkAccount(123));
		} catch (InvalidAccountNoException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			System.out.println(bank.checkAccount(126));
		} catch (InvalidAccountNoException e) {
			System.out.println(e.getMessage());
		}
				
		
	}

}
