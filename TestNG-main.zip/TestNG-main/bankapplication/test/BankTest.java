package com.bankapplication.test;

import java.util.ArrayList;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.bankapplication.entities.Bank;
import com.bankapplication.entities.BankAccount;
import com.bankapplication.exceptions.InvalidAccountNoException;

public class BankTest {
	Bank bank=null;
	@BeforeClass
	public void bankConfig() {
		ArrayList<BankAccount> accounts=new ArrayList<BankAccount>();
		accounts.add(new BankAccount(123,"Gopi",1000));
		accounts.add(new BankAccount(124,"Jai",5000));
		accounts.add(new BankAccount(125,"Raj",2400));
		
		bank=new Bank("icici123","ICICI",accounts);
	}
	@Test(expectedExceptions= {InvalidAccountNoException.class})
	@Parameters("accountNo")
	public void checkAccountTest(int accountNo) throws InvalidAccountNoException {
		Assert.assertNotNull(bank.checkAccount(accountNo));
	}
	@Test
	@Parameters({"accNo","amount"})
	public void depositTest(int accountNo,double amount) throws InvalidAccountNoException {
		Assert.assertTrue(bank.deposit(accountNo, amount));
	}
	@AfterClass
	public void bankConfigGC() {
		bank=null;
	}
}
