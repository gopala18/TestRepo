package com.barcodegen.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DBConnector {

	public static Connection connection = null;

	public static Connection getConnection() throws FileNotFoundException, IOException, SQLException {
		Properties prop = new Properties();
		prop.load(new FileInputStream(new File("ConnectionProperty.properties")));
		StringBuilder connectionString = new StringBuilder();
		connectionString.append("jdbc:postgresql://");
		connectionString.append(prop.getProperty("server"));
		connectionString.append(":" + prop.getProperty("port"));
		connectionString.append("/" + prop.getProperty("dbname"));
		connection = DriverManager.getConnection(connectionString.toString(), prop.getProperty("userName"),
				prop.getProperty("password"));
		return connection;

	}
}
