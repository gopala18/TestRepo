package com.barcodegen.dao;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.ArrayList;

import com.barcodegen.entities.Area;
import com.barcodegen.entities.BarCodeGen;
import com.barcodegen.entities.Category;

public interface BarCodeServiceProvider {

	public String generateBarCode(Area area,Category category);
	public ArrayList<BarCodeGen> searchBarCode(LocalDateTime from,LocalDateTime to) throws FileNotFoundException, IOException, SQLException;
}
