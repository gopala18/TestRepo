package com.barcodegen.services;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.ArrayList;

import com.barcodegen.dao.BarCodeServiceProvider;
import com.barcodegen.entities.Area;
import com.barcodegen.entities.BarCodeGen;
import com.barcodegen.entities.Category;
import com.barcodegen.utils.DBConnector;

public class BarCodeService implements BarCodeServiceProvider {

	@Override
	public String generateBarCode(Area area, Category category) {
		//your barcode logic comes here
		return null;
	}

	@Override
	public ArrayList<BarCodeGen> searchBarCode(LocalDateTime from, LocalDateTime to) throws FileNotFoundException, IOException, SQLException {
		ArrayList<BarCodeGen> barCodes=new ArrayList<>();
		Connection conn=DBConnector.getConnection();
		PreparedStatement ps=conn.prepareStatement("SELECT barcode,date_time,category_id,area_code FROM barcode WHERE date_time BETWEEN ? AND ?");
		ps.setTimestamp(1, java.sql.Timestamp.valueOf(from));
		ps.setTimestamp(2, java.sql.Timestamp.valueOf(to));
		ResultSet rs=ps.executeQuery();
		while(rs.next()) {
			barCodes.add(new BarCodeGen(rs.getString("barcode"),rs.getTimestamp("date_time").toLocalDateTime(),rs.getInt("category_id"),rs.getInt("area_code")));
		}
		return barCodes;
	}

}
